# Nursultan Test (Fabric 1.21.4)

- Кастомное главное меню (Одиночная игра / Сетевая игра / Аккаунты / Настройки / Выйти)
- Аккаунты: свой ник или «Случайный ник», список сохранённых (только offline-серверы)
- Combat: **Kill Aura** (порт Aura из Xyeta) и **Anti Bot**
- ClickGUI — Right Shift. ПКМ по модулю: бинд на клавишу и все настройки (колесо мыши — прокрутка)
- Средняя кнопка мыши по игроку — добавить / убрать друга
- Конфиг: `.minecraft/config/nursultantest.properties`

## Сборка на GitHub
Push в репозиторий → вкладка **Actions → build → Artifacts → nursultan-test** с готовым `.jar`
(кладётся в `.minecraft/mods` вместе с Fabric API).
