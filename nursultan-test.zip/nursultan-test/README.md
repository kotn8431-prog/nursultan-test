# Nursultan Test (Fabric 1.21.4)

- Кастомное главное меню (Одиночная игра / Сетевая игра / Аккаунты / Настройки / Выйти)
- Аккаунты: свой ник или «Случайный ник», список сохранённых (только offline-серверы)
- Combat → Kill Aura (ПКМ по модулю в ClickGUI: бинд на клавишу и настройки)
- ClickGUI — Right Shift, конфиг: `.minecraft/config/nursultantest.properties`

## Сборка на GitHub
Залей папку в репозиторий и сделай push. Вкладка **Actions → build → Artifacts → nursultan-test**
содержит готовый `.jar` (кладётся в `.minecraft/mods` вместе с Fabric API).
