package nursultantest;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

/** Offline nickname switcher. Works on cracked / offline-mode servers. */
public final class AccountManager {
    private AccountManager() {
    }

    private static final String[] PART_A = {"Dark", "Swift", "Frost", "Neon", "Shadow", "Toxic", "Crazy", "Silent",
            "Fire", "Ice", "Mega", "Ultra", "Lucky", "Wild", "Nova", "Pixel", "Storm", "Cyber"};
    private static final String[] PART_B = {"Wolf", "Fox", "Ninja", "Tiger", "Ghost", "Hunter", "Rider", "Knight",
            "Dragon", "Bear", "Hawk", "Viper", "Miner", "Gamer", "Panda", "Blade", "King", "Raven"};

    private static final List<String> SAVED = new ArrayList<>();
    private static Field sessionField;

    public static List<String> saved() {
        return SAVED;
    }

    public static String current() {
        return MinecraftClient.getInstance().getSession().getUsername();
    }

    public static String randomNick() {
        Random r = new Random();
        String nick = PART_A[r.nextInt(PART_A.length)] + PART_B[r.nextInt(PART_B.length)] + r.nextInt(100);
        return nick.length() > 16 ? nick.substring(0, 16) : nick;
    }

    public static boolean isValid(String nick) {
        return nick != null && nick.matches("[A-Za-z0-9_]{3,16}");
    }

    public static void login(String nick) throws ReflectiveOperationException {
        MinecraftClient mc = MinecraftClient.getInstance();
        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + nick).getBytes(StandardCharsets.UTF_8));
        Session session = new Session(nick, uuid, "", Optional.empty(), Optional.empty(), Session.AccountType.LEGACY);
        sessionField().set(mc, session);
        remember(nick);
    }

    private static Field sessionField() throws ReflectiveOperationException {
        if (sessionField == null) {
            String name = FabricLoader.getInstance().getMappingResolver().mapFieldName(
                    "named", "net.minecraft.client.MinecraftClient", "session", "Lnet/minecraft/client/session/Session;");
            Field f = MinecraftClient.class.getDeclaredField(name);
            f.setAccessible(true);
            sessionField = f;
        }
        return sessionField;
    }

    public static void remember(String nick) {
        SAVED.removeIf(s -> s.equalsIgnoreCase(nick));
        SAVED.add(0, nick);
        while (SAVED.size() > 20) SAVED.remove(SAVED.size() - 1);
        save();
    }

    public static void forget(String nick) {
        SAVED.remove(nick);
        save();
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nursultantest-accounts.txt");
    }

    public static void load() {
        SAVED.clear();
        try {
            if (Files.exists(file())) {
                for (String line : Files.readAllLines(file(), StandardCharsets.UTF_8)) {
                    if (isValid(line.trim())) SAVED.add(line.trim());
                }
            }
        } catch (IOException ignored) {
        }
    }

    private static void save() {
        try {
            Files.write(file(), SAVED, StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }
}
