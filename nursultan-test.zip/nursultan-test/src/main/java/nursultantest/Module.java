package nursultantest;

public class Module {
    public final String name;
    public final Category category;
    public boolean enabled;

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public void toggle() {
        enabled = !enabled;
    }
}
