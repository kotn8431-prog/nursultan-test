package nursultantest;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name;
    public final Category category;
    public boolean enabled;
    /** GLFW key code, -1 = not bound. */
    public int key = -1;
    public boolean keyDown;
    public final List<Setting> settings = new ArrayList<>();

    public Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public void toggle() {
        setEnabled(!enabled);
    }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (value) onEnable();
        else onDisable();
    }

    public void onEnable() {
    }

    public void onDisable() {
    }

    public void onTick(MinecraftClient mc) {
    }

    public static String keyName(int key) {
        if (key < 0) return "Нет";
        return InputUtil.Type.KEYSYM.createFromCode(key).getLocalizedText().getString();
    }
}
