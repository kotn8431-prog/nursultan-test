package nursultantest;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Random;

/** Shared look for the custom screens (purple / dark style). */
public final class Ui {
    private Ui() {
    }

    public static final int WHITE = 0xFFFFFFFF;
    public static final int LAVENDER = 0xFFD9B8FF;
    public static final int ACCENT = 0xFFB070FF;

    public static void background(DrawContext ctx, int w, int h) {
        ctx.fillGradient(0, 0, w, h, 0xFF08040F, 0xFF1B0A36);

        // glow behind the logo
        int cx = (int) (w * 0.27);
        int cy = (int) (h * 0.48);
        int base = (int) (h * 0.22);
        for (int i = 12; i >= 0; i--) {
            int s = base + i * (int) (h * 0.035);
            RenderUtil.roundedRect(ctx, cx - s / 2, cy - s / 2, s, s, s / 2, (6 << 24) | 0x7A2CFF);
        }

        // stars
        long t = System.currentTimeMillis();
        Random r = new Random(1337);
        for (int i = 0; i < 110; i++) {
            int x = r.nextInt(Math.max(1, w));
            int y = r.nextInt(Math.max(1, h));
            double phase = r.nextDouble() * Math.PI * 2;
            int a = 40 + (int) (80 * (0.5 + 0.5 * Math.sin(t / 900.0 + phase)));
            int size = r.nextInt(6) == 0 ? 2 : 1;
            ctx.fill(x, y, x + size, y + size, (a << 24) | 0xD9B8FF);
        }
    }

    /** Big glowing "P" logo. */
    public static void logo(DrawContext ctx, TextRenderer tr, int cx, int cy, float scale) {
        Text p = Text.literal("P").formatted(Formatting.BOLD);
        int w = tr.getWidth(p);
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate((float) cx, (float) cy, 0f);
        m.scale(scale, scale, 1f);
        int x = -w / 2;
        int y = -4;
        for (int dx = -2; dx <= 2; dx += 2) {
            for (int dy = -2; dy <= 2; dy += 2) {
                ctx.drawText(tr, p, x + dx, y + dy, 0x30B070FF, false);
            }
        }
        ctx.drawText(tr, p, x + 1, y + 1, 0xFF3B1470, false);
        ctx.drawText(tr, p, x, y, 0xFFC9A0FF, false);
        m.pop();
    }

    public static void gradientText(DrawContext ctx, TextRenderer tr, String s, float cx, float y, float scale, int c1, int c2) {
        int total = 0;
        for (char ch : s.toCharArray()) {
            total += tr.getWidth(Text.literal(String.valueOf(ch)).formatted(Formatting.BOLD));
        }
        MatrixStack m = ctx.getMatrices();
        m.push();
        m.translate(cx, y, 0f);
        m.scale(scale, scale, 1f);
        int x = -total / 2;
        int n = Math.max(1, s.length() - 1);
        for (int i = 0; i < s.length(); i++) {
            Text part = Text.literal(String.valueOf(s.charAt(i))).formatted(Formatting.BOLD);
            ctx.drawText(tr, part, x, 0, lerp(c1, c2, i / (float) n), false);
            x += tr.getWidth(part);
        }
        m.pop();
    }

    public static void button(DrawContext ctx, TextRenderer tr, String label, int x, int y, int w, int h,
                              boolean hover, boolean active) {
        int border = active ? ACCENT : (hover ? 0xAAB070FF : 0x55B070FF);
        int fill = hover ? 0xF02A1450 : 0xE61A0D33;
        RenderUtil.roundedBorder(ctx, x, y, w, h, 6, border, fill);
        int tw = tr.getWidth(label);
        ctx.drawText(tr, label, x + (w - tw) / 2, y + (h - 8) / 2, hover || active ? WHITE : LAVENDER, false);
    }

    public static boolean hit(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    public static int lerp(int c1, int c2, float t) {
        int a = (int) (((c1 >>> 24) & 255) + (((c2 >>> 24) & 255) - ((c1 >>> 24) & 255)) * t);
        int r = (int) (((c1 >> 16) & 255) + (((c2 >> 16) & 255) - ((c1 >> 16) & 255)) * t);
        int g = (int) (((c1 >> 8) & 255) + (((c2 >> 8) & 255) - ((c1 >> 8) & 255)) * t);
        int b = (int) ((c1 & 255) + ((c2 & 255) - (c1 & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
