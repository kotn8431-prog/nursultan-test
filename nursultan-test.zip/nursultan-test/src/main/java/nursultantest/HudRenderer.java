package nursultantest;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;

public class HudRenderer {
    private static final int BG = 0xCC1B2142;
    private static final int PURPLE = 0xFFB48CFF;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int H = 14;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ModuleManager.HUD.enabled || mc.player == null || mc.options.hudHidden) return;

        int x = 4;
        int y = 4;

        // Row 1: watermark + nickname
        int w1 = pill(ctx, mc, x, y, "N", PURPLE, "Release", PURPLE);
        pill(ctx, mc, x + w1 + 3, y, null, 0, mc.player.getName().getString(), WHITE);

        // Row 2: ping
        int ping = 0;
        if (mc.getNetworkHandler() != null) {
            PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            if (entry != null) ping = entry.getLatency();
        }
        pill(ctx, mc, x, y + H + 3, null, 0, ping + " Ping", WHITE);
    }

    private static int pill(DrawContext ctx, MinecraftClient mc, int x, int y,
                            String icon, int iconColor, String text, int textColor) {
        int pad = 5;
        int iconW = icon == null ? 0 : mc.textRenderer.getWidth(icon) + 6;
        int w = pad * 2 + iconW + mc.textRenderer.getWidth(text);
        RenderUtil.roundedRect(ctx, x, y, w, H, 4, BG);
        int tx = x + pad;
        int ty = y + (H - 8) / 2;
        if (icon != null) {
            ctx.drawText(mc.textRenderer, icon, tx, ty, iconColor, false);
            ctx.fill(tx + mc.textRenderer.getWidth(icon) + 2, y + 3, tx + mc.textRenderer.getWidth(icon) + 3, y + H - 3, 0x55FFFFFF);
            tx += iconW;
        }
        ctx.drawText(mc.textRenderer, text, tx, ty, textColor, false);
        return w;
    }
}
