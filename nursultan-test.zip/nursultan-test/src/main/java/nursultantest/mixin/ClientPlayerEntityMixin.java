package nursultantest.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import nursultantest.ModuleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Silent rotation: the server gets the Kill Aura rotation, the camera stays where it is. */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Unique
    private float nt$yaw;
    @Unique
    private float nt$pitch;
    @Unique
    private boolean nt$swapped;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void nt$swapIn(CallbackInfo ci) {
        float[] rot = ModuleManager.KILL_AURA.silentRotation();
        if (rot == null) return;
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        nt$yaw = self.getYaw();
        nt$pitch = self.getPitch();
        self.setYaw(rot[0]);
        self.setPitch(rot[1]);
        nt$swapped = true;
    }

    @Inject(method = "sendMovementPackets", at = @At("RETURN"))
    private void nt$swapOut(CallbackInfo ci) {
        if (!nt$swapped) return;
        ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
        self.setYaw(nt$yaw);
        self.setPitch(nt$pitch);
        nt$swapped = false;
    }
}
