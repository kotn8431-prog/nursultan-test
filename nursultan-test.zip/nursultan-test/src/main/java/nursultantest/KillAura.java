package nursultantest;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Kill Aura, ported from the Xyeta "Aura" module.
 * Not ported: Correction (movement fix for server anticheats), the random rotation jitter / GCD snapping,
 * and the sprint-packet rewriting. Rotation is "silent" (only sent to the server, see ClientPlayerEntityMixin)
 * except while flying with ElytraTarget, where the camera is steered.
 */
public class KillAura extends Module {
    public final NumberSetting preaim = add(new NumberSetting("PreAim", 0.5, 0.0, 2.0, 0.1));
    public final NumberSetting distance = add(new NumberSetting("Distance", 3.0, 3.0, 6.0, 0.1));
    public final ModeSetting espMode = add(new ModeSetting("TargetEsp", "Marker", "Marker", "Fire", "Circle"));
    public final ModeSetting markerMode = add(new ModeSetting("MarkerMode", "Type 1", "Type 1", "Type 2", "Type 3", "Type 4"))
            .showIf(() -> this.espMode.is("Marker"));
    public final MultiSetting targets = add(new MultiSetting("Targets",
            new BoolSetting("Players", true),
            new BoolSetting("Nakeds", true),
            new BoolSetting("Mobs", false),
            new BoolSetting("Animals", false),
            new BoolSetting("Friends", false),
            new BoolSetting("Naked invisibles", false),
            new BoolSetting("Invisibles", false),
            new BoolSetting("Villager", false),
            new BoolSetting("Bots", false)));
    public final MultiSetting sort = add(new MultiSetting("Sort",
            new BoolSetting("Hp", false),
            new BoolSetting("Effects", false),
            new BoolSetting("Distance", true),
            new BoolSetting("Armor", false)));
    public final MultiSetting options = add(new MultiSetting("Options",
            new BoolSetting("Walls", false),
            new BoolSetting("OnlyCrit", false),
            new BoolSetting("NoEatAttack", false),
            new BoolSetting("ElytraTarget", false),
            new BoolSetting("OffSprint", false),
            new BoolSetting("ShieldBreaker", false),
            new BoolSetting("StopUseItem", false),
            new BoolSetting("MakeBoost", false),
            new BoolSetting("SaveTarget", false),
            new BoolSetting("CameraTarget", false)));
    public final ModeSetting offSprintMode = add(new ModeSetting("OffSprintMode", "Default", "Default", "Legit"))
            .showIf(() -> this.options.get("OffSprint"));
    public final BoolSetting smartCrits = add(new BoolSetting("SmartCrits", false))
            .showIf(() -> this.options.get("OnlyCrit"));
    public final BoolSetting miniJump = add(new BoolSetting("MiniJump", false))
            .showIf(() -> this.options.get("OnlyCrit"));
    public final BoolSetting autoFireWork = add(new BoolSetting("AutoFirework", false))
            .showIf(() -> this.options.get("ElytraTarget"));
    public final NumberSetting fireworkCooldown = add(new NumberSetting("FireworkCooldown", 1500, 500, 3000, 50))
            .showIf(() -> this.options.get("ElytraTarget") && this.autoFireWork.value);
    public final BoolSetting betterTarget = add(new BoolSetting("BetterTarget", false))
            .showIf(() -> this.options.get("ElytraTarget"));
    public final NumberSetting elytraDistance = add(new NumberSetting("ElytraDistance", 15, 10, 30, 1))
            .showIf(() -> this.options.get("ElytraTarget"));

    private LivingEntity target;
    private long fireworkAt = System.currentTimeMillis();
    private long attackAt = System.currentTimeMillis();
    private float rotYaw;
    private float rotPitch;
    private float lastYaw;
    private float lastPitch;

    public KillAura() {
        super("Kill Aura", Category.COMBAT);
    }

    private boolean opt(String name) {
        return options.get(name);
    }

    private static boolean reached(long since, long ms) {
        return System.currentTimeMillis() - since > ms;
    }

    public LivingEntity getTarget() {
        return target;
    }

    /** Rotation that is sent to the server (yaw, pitch), or null when there is nothing to aim at. */
    public float[] silentRotation() {
        if (!enabled || target == null) return null;
        return new float[]{rotYaw, rotPitch};
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            rotYaw = mc.player.getYaw();
            rotPitch = mc.player.getPitch();
        }
        target = null;
    }

    @Override
    public void onDisable() {
        target = null;
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            target = null;
            return;
        }

        if (target == null || !isValid(mc, target) || !opt("SaveTarget")) {
            updateTarget(mc);
        }

        if (p.isGliding() && target != null && opt("ElytraTarget") && autoFireWork.value
                && reached(fireworkAt, (long) fireworkCooldown.value)) {
            AuraUtil.sendFireWork(rotYaw, rotPitch);
            fireworkAt = System.currentTimeMillis();
        }

        if (target != null) {
            if (opt("OnlyCrit") && miniJump.value && p.getAttackCooldownProgress(2.0F) == 1.0F && p.isOnGround()) {
                p.setVelocity(0.0, 0.04, 0.0);
            }

            boolean isElytraPvP = p.isGliding() && opt("ElytraTarget");
            boolean inRange = true;
            if (opt("ElytraTarget")) {
                if (p.isGliding()) {
                    inRange = target.distanceTo(p) <= elytraDistance.value;
                } else {
                    inRange = target.distanceTo(p) <= distance.value + preaim.value;
                }
            }
            if (inRange && !isElytraPvP) {
                rotations(mc, target);
            }

            if (!opt("NoEatAttack") || !isUseItems(p)) {
                attack(mc);
            }
        } else {
            rotYaw = p.getYaw();
            rotPitch = p.getPitch();
        }

        if (opt("CameraTarget") && mc.targetedEntity instanceof LivingEntity living
                && target != living && isValid(mc, living)) {
            target = living;
        }
    }

    /** Called every frame (elytra flight needs smooth steering of the camera). */
    public void onRender2D(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!enabled || p == null || target == null) return;
        boolean isElytraPvP = p.isGliding() && opt("ElytraTarget");
        if (!isElytraPvP) return;
        if (!(target.distanceTo(p) <= elytraDistance.value)) return;

        rotations(mc, target);
        p.setYaw(rotYaw);
        p.setPitch(rotPitch);
    }

    private boolean isUseItems(ClientPlayerEntity p) {
        ItemStack blocking = p.getBlockingItem();
        if (opt("StopUseItem") && blocking != null && blocking.getItem() == Items.SHIELD) {
            return false;
        }
        return p.isUsingItem();
    }

    // ---------------------------------------------------------------- render

    public void renderEsp(MatrixStack matrices) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!enabled || target == null || mc.player == null) return;
        if (mc.player.distanceTo(target) <= distance.value + preaim.value) {
            TargetEsp.render(espMode.get(), markerFile(), target, matrices);
        }
    }

    private String markerFile() {
        return switch (markerMode.get()) {
            case "Type 2" -> "targetesp2.jpg";
            case "Type 3" -> "targetesp3.png";
            case "Type 4" -> "targetesp4.png";
            default -> "targetesp1.jpg";
        };
    }

    // ------------------------------------------------------------- targeting

    private void updateTarget(MinecraftClient mc) {
        List<LivingEntity> list = new ArrayList<>();
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof LivingEntity living && isValid(mc, living)) {
                list.add(living);
            }
        }

        if (list.isEmpty()) {
            target = null;
        } else if (list.size() == 1) {
            target = list.get(0);
        } else {
            double maxDist = distance.value + preaim.value;
            list.sort(Comparator.comparingDouble(e -> AuraUtil.entity(e, sort.get("Hp"), sort.get("Armor"),
                    sort.get("Distance"), maxDist, sort.get("Effects"))));
            target = list.get(0);
        }
    }

    private boolean isValid(MinecraftClient mc, LivingEntity entity) {
        ClientPlayerEntity p = mc.player;
        if (entity == null || entity == p || !entity.isAlive() || entity.getHealth() <= 0.0F) return false;

        if (opt("ElytraTarget") && p.isGliding()) {
            return entity instanceof PlayerEntity;
        }

        if (!targets.get("Bots") && ModuleManager.ANTI_BOT.isBot(entity)) return false;
        if (entity instanceof ClientPlayerEntity) return false;
        if (!opt("Walls") && !p.canSee(entity)) return false;

        if ((p.isGliding() || p.getEquippedStack(EquipmentSlot.CHEST).getItem() == Items.ELYTRA) && opt("ElytraTarget")) {
            if (p.distanceTo(entity) > elytraDistance.value) return false;
        } else if (p.distanceTo(entity) >= distance.value + preaim.value) {
            return false;
        }

        if (entity instanceof PlayerEntity player) {
            if (!targets.get("Friends") && FriendManager.isFriend(player.getName().getString())) return false;
            if (player.getName().getString().equalsIgnoreCase(p.getName().getString())) return false;
        }

        if (entity instanceof PlayerEntity && !targets.get("Players")) return false;
        if (entity instanceof VillagerEntity && !targets.get("Villager")) return false;
        if (entity instanceof PlayerEntity && entity.getArmor() == 0 && !targets.get("Nakeds")) return false;
        if (entity instanceof PlayerEntity && entity.isInvisible() && entity.getArmor() == 0 && !targets.get("Naked invisibles")) return false;
        if (entity instanceof PlayerEntity && entity.isInvisible() && !targets.get("Invisibles")) return false;
        if (entity instanceof Monster && !targets.get("Mobs")) return false;
        if (entity instanceof AnimalEntity && !targets.get("Animals")) return false;

        return !entity.isInvulnerable() && entity.isAlive() && !(entity instanceof ArmorStandEntity);
    }

    // -------------------------------------------------------------- rotation

    private void rotations(MinecraftClient mc, LivingEntity t) {
        ClientPlayerEntity p = mc.player;

        if (p.isGliding() && opt("ElytraTarget")) {
            Vec3d vec = t.getPos()
                    .add(0.0, MathHelper.clamp(p.getEyeY() - t.getY(), 0.0,
                            t.getHeight() * (p.distanceTo(t) / distance.value)), 0.0)
                    .subtract(p.getCameraPosVec(1.0F));
            float yawToTarget = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vec.z, vec.x)) - 90.0);
            float pitchToTarget = (float) (-Math.toDegrees(Math.atan2(vec.y, Math.hypot(vec.x, vec.z))));
            float yawDelta = MathHelper.wrapDegrees(yawToTarget - rotYaw);
            float pitchDelta = MathHelper.wrapDegrees(pitchToTarget - rotPitch);
            float s = 0.26F;
            float clampedYaw = Math.min(Math.max(Math.abs(yawDelta), 1.0F), 6.0F + s);
            float clampedPitch = Math.min(Math.max(Math.abs(pitchDelta), 1.0F), 5.07F + s);
            if (Math.abs(clampedYaw - lastYaw) <= 3.0F) {
                clampedYaw = lastYaw + 2.5F;
            }
            float yaw = rotYaw + (yawDelta > 0.0F ? clampedYaw : -clampedYaw);
            float pitch = MathHelper.clamp(rotPitch + (pitchDelta > 0.0F ? clampedPitch : -clampedPitch), -89.0F, 89.0F);
            rotYaw = yaw;
            rotPitch = pitch;
            lastYaw = clampedYaw;
            lastPitch = clampedPitch;
        } else {
            Vec3d torso = t.getPos().add(0.0, t.getHeight() / 2.0F, 0.0);
            Vec3d vec = torso.subtract(p.getEyePos());
            float yawToTarget = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vec.z, vec.x)) - 90.0);
            float pitchToTarget = (float) (-Math.toDegrees(Math.atan2(vec.y, Math.hypot(vec.x, vec.z))));
            float yawDelta = MathHelper.wrapDegrees(yawToTarget - rotYaw);
            float pitchDelta = MathHelper.wrapDegrees(pitchToTarget - rotPitch);
            rotYaw = rotYaw + yawDelta;
            rotPitch = MathHelper.clamp(rotPitch + pitchDelta, -89.0F, 89.0F);
        }
    }

    // ---------------------------------------------------------------- attack

    private void disableSprint(ClientPlayerEntity p, MinecraftClient mc) {
        if (!p.isGliding() && p.isSprinting() && opt("OffSprint")) {
            switch (offSprintMode.get()) {
                case "Default" -> {
                    p.input.movementSideways = 0.0F;
                    p.input.movementForward = 0.0F;
                    p.setSprinting(false);
                    mc.options.sprintKey.setPressed(false);
                    p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                }
                case "Legit" -> {
                    p.input.movementForward = 0.0F;
                    p.input.movementSideways = 0.0F;
                    mc.options.sprintKey.setPressed(false);
                    p.setSprinting(false);
                }
                default -> {
                }
            }
        }
    }

    private void attack(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        boolean canAttack = opt("OnlyCrit")
                ? AuraUtil.canAttack(smartCrits.value)
                : (double) p.getAttackCooldownProgress(2.0F) >= 0.97;

        if (canAttack && target.distanceTo(p) <= distance.value && reached(attackAt, 540)) {
            int previousSlot = p.getInventory().selectedSlot;
            boolean swapped = false;
            if (opt("MakeBoost")) {
                for (int i = 0; i < 9 && !swapped; ++i) {
                    if (p.getInventory().getStack(i).getItem() == Items.MACE) {
                        p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(i));
                        swapped = true;
                    }
                }
            }

            disableSprint(p, mc);
            ItemStack blocking = p.getBlockingItem();
            if (opt("StopUseItem") && blocking != null && blocking.getItem() == Items.SHIELD) {
                mc.interactionManager.stopUsingItem(p);
            }

            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
            if (opt("MakeBoost") && swapped) {
                p.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(previousSlot));
            }

            if (opt("ShieldBreaker") && target instanceof PlayerEntity player) {
                AuraUtil.breakShield(player);
            }

            if (p.isGliding() && opt("ElytraTarget")
                    && (reached(fireworkAt, 1200) || betterTarget.value)) {
                AuraUtil.sendFireWork(rotYaw, rotPitch);
                fireworkAt = System.currentTimeMillis();
            }

            attackAt = System.currentTimeMillis();
        }
    }
}
