package nursultantest;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * KillAura (ported from the Xyeta Aura module, simplified):
 * picks the closest valid target, turns towards it and attacks when the cooldown is ready.
 */
public class KillAura extends Module {
    public final NumberSetting range = add(new NumberSetting("Range", 3.0, 2.5, 6.0, 0.1));
    public final BoolSetting rotate = add(new BoolSetting("Rotate", true));
    public final NumberSetting rotateSpeed = add(new NumberSetting("Rotate speed", 45, 5, 180, 1));
    public final BoolSetting players = add(new BoolSetting("Players", true));
    public final BoolSetting mobs = add(new BoolSetting("Mobs", false));
    public final BoolSetting animals = add(new BoolSetting("Animals", false));
    public final BoolSetting walls = add(new BoolSetting("Through walls", false));

    private LivingEntity target;

    public KillAura() {
        super("Kill Aura", Category.COMBAT);
    }

    public LivingEntity getTarget() {
        return target;
    }

    @Override
    public void onDisable() {
        target = null;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) {
            target = null;
            return;
        }

        target = findTarget(mc, player);
        if (target == null) return;

        Vec3d eye = player.getEyePos();
        Vec3d aim = aimPoint(target, eye);

        boolean onTarget = true;
        if (rotate.value) {
            float[] want = angles(eye, aim);
            float dYaw = MathHelper.wrapDegrees(want[0] - player.getYaw());
            float dPitch = want[1] - player.getPitch();
            float speed = rotateSpeed.f();
            player.setYaw(player.getYaw() + MathHelper.clamp(dYaw, -speed, speed));
            player.setPitch(MathHelper.clamp(player.getPitch() + MathHelper.clamp(dPitch, -speed, speed), -90f, 90f));
            onTarget = Math.abs(MathHelper.wrapDegrees(want[0] - player.getYaw())) <= 20f
                    && Math.abs(want[1] - player.getPitch()) <= 20f;
        }

        if (onTarget && player.getAttackCooldownProgress(0.5f) >= 0.95f) {
            mc.interactionManager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
        }
    }

    private LivingEntity findTarget(MinecraftClient mc, ClientPlayerEntity player) {
        Vec3d eye = player.getEyePos();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity living) || !isValid(player, living)) continue;
            double dist = eye.distanceTo(closestPoint(living.getBoundingBox(), eye));
            if (dist > range.value || dist >= bestDist) continue;
            if (!walls.value && !player.canSee(living)) continue;
            best = living;
            bestDist = dist;
        }
        return best;
    }

    private boolean isValid(ClientPlayerEntity player, LivingEntity e) {
        if (e == player || !e.isAlive() || e.getHealth() <= 0f || e.isInvulnerable()) return false;
        if (e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity p) return players.value && !p.isSpectator();
        if (e instanceof Monster) return mobs.value;
        if (e instanceof AnimalEntity) return animals.value;
        return false;
    }

    private static Vec3d closestPoint(Box box, Vec3d p) {
        return new Vec3d(
                MathHelper.clamp(p.x, box.minX, box.maxX),
                MathHelper.clamp(p.y, box.minY, box.maxY),
                MathHelper.clamp(p.z, box.minZ, box.maxZ));
    }

    private static Vec3d aimPoint(LivingEntity e, Vec3d eye) {
        Box b = e.getBoundingBox();
        return new Vec3d(e.getX(), MathHelper.clamp(eye.y, b.minY + 0.1, b.maxY - 0.1), e.getZ());
    }

    private static float[] angles(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        return new float[]{MathHelper.wrapDegrees(yaw), MathHelper.clamp(pitch, -90f, 90f)};
    }
}
