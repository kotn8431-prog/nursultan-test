package nursultantest;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int GAP = 4;
    private static final int HEADER = 22;
    private static final int ROW = 16;
    private static final int ROW_GAP = 2;

    private static final int PANEL_BG = 0xE61A1D3B;
    private static final int ROW_BG = 0xFF24284F;
    private static final int ROW_HOVER = 0xFF2E3363;
    private static final int ROW_ON = 0xFF5B46C9;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFAAAAAA;

    public ClickGuiScreen() {
        super(Text.literal("Nursultan Test"));
    }

    private int panelW() {
        return Math.min(130, (width - GAP * 6) / 5);
    }

    private int panelH() {
        return Math.min(height - 70, 260);
    }

    private int startX() {
        return (width - (panelW() * 5 + GAP * 4)) / 2;
    }

    private int startY() {
        return Math.max(10, (height - panelH() - 40) / 2);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        int pw = panelW();
        int ph = panelH();
        int sx = startX();
        int sy = startY();
        Category[] cats = Category.values();

        for (int i = 0; i < cats.length; i++) {
            int px = sx + i * (pw + GAP);
            RenderUtil.roundedRect(ctx, px, sy, pw, ph, 6, PANEL_BG);

            String title = cats[i].title;
            int tw = textRenderer.getWidth(title);
            ctx.drawText(textRenderer, title, px + (pw - tw) / 2, sy + 7, WHITE, false);

            List<Module> mods = ModuleManager.of(cats[i]);
            int ry = sy + HEADER;
            for (Module m : mods) {
                int rx = px + 5;
                int rw = pw - 10;
                boolean hover = mouseX >= rx && mouseX <= rx + rw && mouseY >= ry && mouseY <= ry + ROW;
                int color = m.enabled ? ROW_ON : (hover ? ROW_HOVER : ROW_BG);
                RenderUtil.roundedRect(ctx, rx, ry, rw, ROW, 4, color);
                ctx.drawText(textRenderer, m.name, rx + 6, ry + 4, WHITE, false);
                if (m.key >= 0) {
                    String kn = Module.keyName(m.key);
                    if (kn.length() > 3) kn = kn.substring(0, 3);
                    kn = kn.toUpperCase();
                    ctx.drawText(textRenderer, kn, rx + rw - 5 - textRenderer.getWidth(kn), ry + 4, GRAY, false);
                }
                ry += ROW + ROW_GAP;
            }
        }

        // Search bar (decoration only)
        int sbW = pw;
        int sbX = (width - sbW) / 2;
        int sbY = sy + ph + 8;
        RenderUtil.roundedRect(ctx, sbX, sbY, sbW, 18, 5, PANEL_BG);
        ctx.drawText(textRenderer, "Поиск", sbX + 8, sbY + 5, GRAY, false);
        String hint = "ЛКМ — вкл/выкл  |  ПКМ — настройки и бинд";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2, sbY + 24, GRAY, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 || button == 1) {
            int pw = panelW();
            int sx = startX();
            int sy = startY();
            Category[] cats = Category.values();
            for (int i = 0; i < cats.length; i++) {
                int px = sx + i * (pw + GAP);
                int ry = sy + HEADER;
                for (Module m : ModuleManager.of(cats[i])) {
                    int rx = px + 5;
                    int rw = pw - 10;
                    if (mouseX >= rx && mouseX <= rx + rw && mouseY >= ry && mouseY <= ry + ROW) {
                        if (button == 0) m.toggle();
                        else client.setScreen(new ModuleSettingsScreen(m, this));
                        return true;
                    }
                    ry += ROW + ROW_GAP;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
