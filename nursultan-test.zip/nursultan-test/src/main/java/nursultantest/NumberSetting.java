package nursultantest;

public class NumberSetting extends Setting {
    public double value;
    public final double min;
    public final double max;
    public final double step;

    public NumberSetting(String name, double value, double min, double max, double step) {
        super(name);
        this.value = value;
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public float f() {
        return (float) value;
    }
}
