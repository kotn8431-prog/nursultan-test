package nursultantest;

import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final Module AUTO_SPRINT = new Module("Auto Sprint", Category.MOVEMENT);
    public static final Module HUD = new Module("HUD", Category.VISUALS);
    public static final KillAura KILL_AURA = new KillAura();
    public static final AntiBot ANTI_BOT = new AntiBot();

    public static final List<Module> ALL = new ArrayList<>();

    static {
        ALL.add(KILL_AURA);
        ALL.add(ANTI_BOT);
        ALL.add(AUTO_SPRINT);
        ALL.add(HUD);
        HUD.enabled = true;
    }

    public static List<Module> of(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : ALL) {
            if (m.category == category) result.add(m);
        }
        return result;
    }

    public static void tick(MinecraftClient client) {
        for (Module m : ALL) {
            if (m.enabled) m.onTick(client);
        }
    }
}
