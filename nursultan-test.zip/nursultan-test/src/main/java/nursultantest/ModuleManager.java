package nursultantest;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final Module AUTO_SPRINT = new Module("Auto Sprint", Category.MOVEMENT);
    public static final Module HUD = new Module("HUD", Category.VISUALS);

    public static final List<Module> ALL = new ArrayList<>();

    static {
        ALL.add(AUTO_SPRINT);
        ALL.add(HUD);
        HUD.enabled = true;
    }

    public static List<Module> of(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : ALL) {
            if (m.category == category) result.add(m);
        }
        return result;
    }
}
