package nursultantest;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/** Settings of one module: keybind + its settings. Opened with right click in the ClickGUI. */
public class ModuleSettingsScreen extends Screen {
    private static final int W = 240;
    private static final int ROW = 20;
    private static final int GAP = 4;

    private final Module module;
    private final Screen parent;
    private boolean listening;
    private NumberSetting dragging;

    public ModuleSettingsScreen(Module module, Screen parent) {
        super(Text.literal(module.name));
        this.module = module;
        this.parent = parent;
    }

    private int x() {
        return (width - W) / 2;
    }

    private int panelH() {
        return 34 + (ROW + GAP) * (module.settings.size() + 1) + 24;
    }

    private int y0() {
        return Math.max(6, (height - panelH()) / 2);
    }

    private int rowY(int i) {
        return y0() + 30 + i * (ROW + GAP);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xB0000000, 0xB0100620);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        int x = x();
        RenderUtil.roundedBorder(ctx, x - 12, y0() - 8, W + 24, panelH(), 8, 0x66B070FF, 0xF0120824);
        Ui.gradientText(ctx, textRenderer, module.name, width / 2f, y0() + 2, 1.5f, 0xFFB070FF, 0xFFE8D4FF);

        String bind = listening ? "нажмите клавишу..." : Module.keyName(module.key);
        Ui.button(ctx, textRenderer, "Бинд: " + bind, x, rowY(0), W, ROW,
                Ui.hit(mouseX, mouseY, x, rowY(0), W, ROW), listening);

        for (int i = 0; i < module.settings.size(); i++) {
            Setting s = module.settings.get(i);
            int y = rowY(i + 1);
            boolean hover = Ui.hit(mouseX, mouseY, x, y, W, ROW);
            if (s instanceof BoolSetting b) {
                Ui.button(ctx, textRenderer, s.name + ": " + (b.value ? "ВКЛ" : "ВЫКЛ"), x, y, W, ROW, hover, b.value);
            } else if (s instanceof NumberSetting n) {
                RenderUtil.roundedBorder(ctx, x, y, W, ROW, 6, hover ? 0xAAB070FF : 0x55B070FF, 0xE61A0D33);
                int fillW = (int) ((W - 4) * ((n.value - n.min) / (n.max - n.min)));
                if (fillW > 0) RenderUtil.roundedRect(ctx, x + 2, y + 2, fillW, ROW - 4, 4, 0xCC5B46C9);
                String label = s.name + ": " + String.format(Locale.ROOT, n.step >= 1 ? "%.0f" : "%.1f", n.value);
                ctx.drawText(textRenderer, label, x + (W - textRenderer.getWidth(label)) / 2, y + 6, Ui.WHITE, false);
            }
        }

        String hint = "ПКМ по бинду — сбросить  |  Esc — назад";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2,
                y0() + panelH() - 22, 0xFF9A86C4, false);
    }

    private void updateSlider(NumberSetting n, double mouseX) {
        double t = MathHelper.clamp((mouseX - x()) / W, 0.0, 1.0);
        double v = n.min + t * (n.max - n.min);
        v = Math.round(v / n.step) * n.step;
        n.value = MathHelper.clamp(v, n.min, n.max);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int x = x();
        if (Ui.hit(mx, my, x, rowY(0), W, ROW)) {
            if (button == 0) {
                listening = true;
            } else if (button == 1) {
                module.key = -1;
                listening = false;
                Config.save();
            }
            return true;
        }
        if (button == 0) {
            for (int i = 0; i < module.settings.size(); i++) {
                if (!Ui.hit(mx, my, x, rowY(i + 1), W, ROW)) continue;
                Setting s = module.settings.get(i);
                if (s instanceof BoolSetting b) {
                    b.value = !b.value;
                    Config.save();
                } else if (s instanceof NumberSetting n) {
                    dragging = n;
                    updateSlider(n, mx);
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            updateSlider(dragging, mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening) {
            if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                module.key = -1;
            } else if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                module.key = keyCode;
            }
            listening = false;
            Config.save();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }
}
