package nursultantest;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Settings of one module: keybind + its settings (scrollable). Opened with right click in the ClickGUI. */
public class ModuleSettingsScreen extends Screen {
    private static final int W = 240;
    private static final int ROW = 20;
    private static final int GAP = 4;
    private static final int INDENT = 12;

    /** s == null is the keybind row. */
    private record Row(Setting s, int indent) {
    }

    private final Module module;
    private final Screen parent;
    private boolean listening;
    private NumberSetting dragging;
    private int draggingIndent;
    private double scroll;

    public ModuleSettingsScreen(Module module, Screen parent) {
        super(Text.literal(module.name));
        this.module = module;
        this.parent = parent;
    }

    private int x() {
        return (width - W) / 2;
    }

    private int panelH() {
        return Math.min(height - 16, 320);
    }

    private int y0() {
        return (height - panelH()) / 2;
    }

    private int viewTop() {
        return y0() + 28;
    }

    private int viewBottom() {
        return y0() + panelH() - 22;
    }

    private List<Row> rows() {
        List<Row> rows = new ArrayList<>();
        rows.add(new Row(null, 0));
        for (Setting s : module.settings) {
            if (!s.isVisible()) continue;
            rows.add(new Row(s, 0));
            if (s instanceof MultiSetting m && m.expanded) {
                for (BoolSetting b : m.items) rows.add(new Row(b, 1));
            }
        }
        return rows;
    }

    private double maxScroll(int rowCount) {
        return Math.max(0, rowCount * (ROW + GAP) - (viewBottom() - viewTop()));
    }

    private int rowY(int i) {
        return viewTop() + i * (ROW + GAP) - (int) scroll;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fillGradient(0, 0, width, height, 0xB0000000, 0xB0100620);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        List<Row> rows = rows();
        scroll = MathHelper.clamp(scroll, 0, maxScroll(rows.size()));

        int x = x();
        RenderUtil.roundedBorder(ctx, x - 12, y0() - 4, W + 24, panelH() + 8, 8, 0x66B070FF, 0xF0120824);
        Ui.gradientText(ctx, textRenderer, module.name, width / 2f, y0() + 8, 1.5f, 0xFFB070FF, 0xFFE8D4FF);

        ctx.enableScissor(x - 4, viewTop(), x + W + 4, viewBottom());
        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int y = rowY(i);
            if (y + ROW < viewTop() || y > viewBottom()) continue;
            int rx = x + row.indent() * INDENT;
            int rw = W - row.indent() * INDENT;
            boolean hover = mouseY >= viewTop() && mouseY <= viewBottom() && Ui.hit(mouseX, mouseY, rx, y, rw, ROW);
            drawRow(ctx, row, rx, y, rw, hover);
        }
        ctx.disableScissor();

        String hint = "Колесо — прокрутка  |  ПКМ по бинду — сбросить  |  Esc — назад";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2,
                y0() + panelH() - 14, 0xFF9A86C4, false);
    }

    private void drawRow(DrawContext ctx, Row row, int x, int y, int w, boolean hover) {
        Setting s = row.s();
        if (s == null) {
            String bind = listening ? "нажмите клавишу..." : Module.keyName(module.key);
            Ui.button(ctx, textRenderer, "Бинд: " + bind, x, y, w, ROW, hover, listening);
        } else if (s instanceof BoolSetting b) {
            Ui.button(ctx, textRenderer, s.name + ": " + (b.value ? "ВКЛ" : "ВЫКЛ"), x, y, w, ROW, hover, b.value);
        } else if (s instanceof ModeSetting m) {
            Ui.button(ctx, textRenderer, s.name + ": " + m.get(), x, y, w, ROW, hover, false);
        } else if (s instanceof MultiSetting m) {
            String label = s.name + " (" + m.enabledCount() + "/" + m.items.size() + ") " + (m.expanded ? "[-]" : "[+]");
            Ui.button(ctx, textRenderer, label, x, y, w, ROW, hover, m.expanded);
        } else if (s instanceof NumberSetting n) {
            RenderUtil.roundedBorder(ctx, x, y, w, ROW, 6, hover ? 0xAAB070FF : 0x55B070FF, 0xE61A0D33);
            int fillW = (int) ((w - 4) * ((n.value - n.min) / (n.max - n.min)));
            if (fillW > 0) RenderUtil.roundedRect(ctx, x + 2, y + 2, fillW, ROW - 4, 4, 0xCC5B46C9);
            String label = s.name + ": " + String.format(Locale.ROOT, n.step >= 1 ? "%.0f" : "%.1f", n.value);
            ctx.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + 6, Ui.WHITE, false);
        }
    }

    private void updateSlider(NumberSetting n, double mouseX, int indent) {
        int rx = x() + indent * INDENT;
        int rw = W - indent * INDENT;
        double t = MathHelper.clamp((mouseX - rx) / rw, 0.0, 1.0);
        double v = n.min + t * (n.max - n.min);
        v = Math.round(v / n.step) * n.step;
        n.value = MathHelper.clamp(v, n.min, n.max);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (my >= viewTop() && my <= viewBottom()) {
            List<Row> rows = rows();
            for (int i = 0; i < rows.size(); i++) {
                Row row = rows.get(i);
                int rx = x() + row.indent() * INDENT;
                int rw = W - row.indent() * INDENT;
                if (!Ui.hit(mx, my, rx, rowY(i), rw, ROW)) continue;

                Setting s = row.s();
                if (s == null) {
                    if (button == 0) {
                        listening = true;
                    } else if (button == 1) {
                        module.key = -1;
                        listening = false;
                        Config.save();
                    }
                } else if (s instanceof BoolSetting b && button == 0) {
                    b.value = !b.value;
                    Config.save();
                } else if (s instanceof ModeSetting m) {
                    if (button == 0) m.next();
                    else if (button == 1) m.prev();
                    Config.save();
                } else if (s instanceof MultiSetting m && button == 0) {
                    m.expanded = !m.expanded;
                } else if (s instanceof NumberSetting n && button == 0) {
                    dragging = n;
                    draggingIndent = row.indent();
                    updateSlider(n, mx, row.indent());
                }
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            updateSlider(dragging, mx, draggingIndent);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            Config.save();
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        scroll = MathHelper.clamp(scroll - vertical * (ROW + GAP), 0, maxScroll(rows().size()));
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening) {
            if (keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                module.key = -1;
            } else if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                module.key = keyCode;
            }
            listening = false;
            Config.save();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(parent);
    }
}
