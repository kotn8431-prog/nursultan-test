package nursultantest;

public class ModeSetting extends Setting {
    public final String[] modes;
    public int index;

    public ModeSetting(String name, String def, String... modes) {
        super(name);
        this.modes = modes;
        set(def);
    }

    public String get() {
        return modes[index];
    }

    public boolean is(String mode) {
        return get().equals(mode);
    }

    public void set(String mode) {
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equals(mode)) {
                index = i;
                return;
            }
        }
    }

    public void next() {
        index = (index + 1) % modes.length;
    }

    public void prev() {
        index = (index - 1 + modes.length) % modes.length;
    }
}
