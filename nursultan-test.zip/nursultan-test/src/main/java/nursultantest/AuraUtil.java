package nursultantest;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

/** Ported from Xyeta: AuraUtil + the inventory helpers Aura needs. */
public final class AuraUtil {
    private AuraUtil() {
    }

    private static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    // ---------- crits ----------

    private static boolean isCrit() {
        MinecraftClient mc = mc();
        boolean disableCrit = mc.player.isInLava() || mc.player.isSubmergedInWater() || mc.player.isGliding();
        if (!disableCrit) {
            return !mc.player.isOnGround() && mc.player.getMovement().y < -0.1 && mc.player.getVelocity().y < 0.08;
        }
        return true;
    }

    private static boolean critCheck(boolean smartCrits) {
        if (smartCrits) {
            return mc().options.jumpKey.isPressed() ? isCrit() : true;
        }
        return isCrit();
    }

    public static boolean canAttack(boolean smartCrits) {
        return (double) mc().player.getAttackCooldownProgress(2.0F) >= 0.97 && critCheck(smartCrits);
    }

    // ---------- shield breaker ----------

    public static void breakShield(LivingEntity target) {
        MinecraftClient mc = mc();
        if (target.isBlocking() && target.getBlockingItem().getItem() == Items.SHIELD) {
            int invSlot = getAxeInInventoryOrHotbar(false);
            int hotBarSlot = getAxeInInventoryOrHotbar(true);
            if (hotBarSlot == -1 && invSlot != -1) {
                int bestSlot = findBestSlotInHotBar();
                if (bestSlot == -1) return;
                mc.interactionManager.clickSlot(0, invSlot, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(0, bestSlot + 36, 0, SlotActionType.PICKUP, mc.player);
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(bestSlot));
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().selectedSlot));
                mc.interactionManager.clickSlot(0, bestSlot + 36, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(0, invSlot, 0, SlotActionType.PICKUP, mc.player);
            }

            if (hotBarSlot != -1) {
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(hotBarSlot));
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().selectedSlot));
            }
        }
    }

    public static int getAxeInInventoryOrHotbar(boolean inHotBar) {
        MinecraftClient mc = mc();
        int firstSlot = inHotBar ? 0 : 9;
        int lastSlot = inHotBar ? 9 : 36;
        int finalSlot = -1;
        for (int i = firstSlot; i < lastSlot; ++i) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                finalSlot = i;
            }
        }
        return finalSlot;
    }

    public static int findBestSlotInHotBar() {
        int emptySlot = findEmptySlot();
        return emptySlot != -1 ? emptySlot : findNonSwordSlot();
    }

    private static int findEmptySlot() {
        MinecraftClient mc = mc();
        for (int i = 0; i < 9; ++i) {
            if (mc.player.getInventory().getStack(i).isEmpty() && mc.player.getInventory().selectedSlot != i) {
                return i;
            }
        }
        return -1;
    }

    private static int findNonSwordSlot() {
        MinecraftClient mc = mc();
        for (int i = 0; i < 9; ++i) {
            Item item = mc.player.getInventory().getStack(i).getItem();
            if (!(item instanceof SwordItem) && item != Items.ELYTRA && mc.player.getInventory().selectedSlot != i) {
                return i;
            }
        }
        return -1;
    }

    // ---------- elytra ----------

    public static void sendFireWork(float yaw, float pitch) {
        MinecraftClient mc = mc();
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = mc.player.getInventory().getStack(i);
            if (itemStack.getItem() instanceof FireworkRocketItem) {
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(i));
                mc.player.networkHandler.sendPacket(new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, i, yaw, pitch));
                mc.player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(mc.player.getInventory().selectedSlot));
                return;
            }
        }
    }

    // ---------- target sorting ----------

    private static double armorItem(ItemStack stack) {
        if (!(stack.getItem() instanceof ArmorItem)) {
            return 0.0;
        } else if (mc().world == null) {
            return 0.0;
        } else {
            double armorValue = 0.0;
            AttributeModifiersComponent modifiers = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
            if (modifiers != null) {
                for (AttributeModifiersComponent.Entry entry : modifiers.modifiers()) {
                    if (entry.attribute().value() == EntityAttributes.ARMOR) {
                        armorValue += entry.modifier().value();
                    }
                }
            }

            ItemEnchantmentsComponent enchants = stack.get(DataComponentTypes.ENCHANTMENTS);
            if (enchants != null) {
                for (Object2IntMap.Entry<RegistryEntry<Enchantment>> entry : enchants.getEnchantmentEntries()) {
                    if (entry.getKey().matchesKey(Enchantments.PROTECTION)) {
                        armorValue += (double) entry.getIntValue() * 0.25;
                    }
                }
            }
            return armorValue;
        }
    }

    public static double armor(LivingEntity entity) {
        double armor = entity.getArmor();
        for (ItemStack item : entity.getArmorItems()) {
            armor += armorItem(item);
        }
        return armor;
    }

    public static double health(LivingEntity entity) {
        return entity.getHealth() + entity.getAbsorptionAmount();
    }

    public static double buffs(LivingEntity entity) {
        double buffs = 0.0;
        for (StatusEffectInstance effect : entity.getStatusEffects()) {
            StatusEffect type = effect.getEffectType().value();
            if (type == StatusEffects.ABSORPTION.value()) {
                buffs += 1.2 * (effect.getAmplifier() + 1);
            } else if (type == StatusEffects.RESISTANCE.value()) {
                buffs += 1.0 * (effect.getAmplifier() + 1);
            } else if (type == StatusEffects.REGENERATION.value()) {
                buffs += 1.1 * (effect.getAmplifier() + 1);
            }
        }
        return buffs;
    }

    public static double entity(LivingEntity entity, boolean health, boolean armor, boolean distance,
                                double maxDistance, boolean buffs) {
        double a = 1.0, b = 1.0, c = 1.0, d = 1.0;
        if (health) a += health(entity);
        if (armor) b += armor(entity);
        if (distance) c += (double) entity.distanceTo(mc().player) / maxDistance;
        if (buffs) d += buffs(entity);
        return a * b * d * c;
    }
}
