package nursultantest;

import net.minecraft.client.gui.DrawContext;

public class RenderUtil {
    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        ctx.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void roundedBorder(DrawContext ctx, int x, int y, int w, int h, int r, int border, int fill) {
        roundedRect(ctx, x, y, w, h, r, border);
        roundedRect(ctx, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }
}
