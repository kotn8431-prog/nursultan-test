package nursultantest;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/** Friends are not attacked by Kill Aura (unless "Friends" target is on). Middle click on a player toggles. */
public final class FriendManager {
    private FriendManager() {
    }

    private static final Set<String> FRIENDS = new LinkedHashSet<>();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nursultantest-friends.txt");
    }

    public static boolean isFriend(String name) {
        return FRIENDS.contains(name.toLowerCase(Locale.ROOT));
    }

    /** @return true if the player was added, false if removed */
    public static boolean toggle(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        boolean added = FRIENDS.add(key);
        if (!added) FRIENDS.remove(key);
        save();
        return added;
    }

    public static void load() {
        FRIENDS.clear();
        try {
            if (Files.exists(file())) {
                for (String line : Files.readAllLines(file(), StandardCharsets.UTF_8)) {
                    if (!line.isBlank()) FRIENDS.add(line.trim().toLowerCase(Locale.ROOT));
                }
            }
        } catch (IOException ignored) {
        }
    }

    private static void save() {
        try {
            Files.write(file(), FRIENDS, StandardCharsets.UTF_8);
        } catch (IOException ignored) {
        }
    }
}
