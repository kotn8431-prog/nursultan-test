package nursultantest;

import com.mojang.blaze3d.platform.GlStateManager.DstFactor;
import com.mojang.blaze3d.platform.GlStateManager.SrcFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat.DrawMode;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

/** Target ESP modes ported from Xyeta (Marker / Fire / Circle). */
public final class TargetEsp {
    private TargetEsp() {
    }

    /** Theme colour (ARGB). */
    private static final int THEME = 0xFFB070FF;
    private static final Identifier FIRE = Identifier.of("nursultantest", "images/targetesps/fire.png");

    private static MinecraftClient mc() {
        return MinecraftClient.getInstance();
    }

    private static float tickDelta() {
        return mc().getRenderTickCounter().getTickDelta(false);
    }

    public static void render(String mode, String markerFile, Entity target, MatrixStack matrices) {
        switch (mode) {
            case "Fire" -> fire(target);
            case "Circle" -> circle(target, matrices);
            default -> marker(target, matrices, markerFile);
        }
    }

    // ---------------------------------------------------------------- Marker

    private static float rotationAngle = 0.0F;
    private static float rotationSpeed = 0.0F;
    private static boolean isReversing = false;
    private static long lastUpdateTime = System.currentTimeMillis();

    private static void markerTick() {
        long currentTime = System.currentTimeMillis();
        long deltaTime = currentTime - lastUpdateTime;
        float deltaSeconds = (float) deltaTime * 0.2F;
        if (!isReversing) {
            rotationSpeed += 0.02F * deltaSeconds;
            if (rotationSpeed > 3.0F) {
                rotationSpeed = 3.0F;
                isReversing = true;
            }
        } else {
            rotationSpeed -= 0.02F * deltaSeconds;
            if (rotationSpeed < -3.0F) {
                rotationSpeed = -3.0F;
                isReversing = false;
            }
        }
        rotationAngle += rotationSpeed * deltaSeconds;
        rotationAngle = (rotationAngle + 360.0F) % 360.0F;
        lastUpdateTime = currentTime;
    }

    private static void marker(Entity target, MatrixStack matrices, String file) {
        MinecraftClient mc = mc();
        if (target == null || target == mc.player || target instanceof ArmorStandEntity) return;

        Camera camera = mc.gameRenderer.getCamera();
        Box hitBox = target.getBoundingBox();
        Vec3d targetPos = target.getLerpedPos(tickDelta()).subtract(camera.getPos());
        double tPosX = targetPos.x;
        double tPosY = targetPos.y + (hitBox.maxY - hitBox.minY) / 2.0;
        double tPosZ = targetPos.z;
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        matrices.push();
        matrices.translate(tPosX, tPosY, tPosZ);
        matrices.multiply(camera.getRotation());
        matrices.scale(0.6F, 0.6F, 0.6F);
        markerTick();
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rotationAngle));
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
        RenderSystem.setShaderTexture(0, Identifier.of("nursultantest", "images/targetesps/" + file));
        matrices.translate(-0.75F, -0.75F, -0.01);
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(matrix, 0.0F, 1.5F, 0.0F).texture(0.0F, 1.0F).color(THEME);
        buffer.vertex(matrix, 1.5F, 1.5F, 0.0F).texture(1.0F, 1.0F).color(THEME);
        buffer.vertex(matrix, 1.5F, 0.0F, 0.0F).texture(1.0F, 0.0F).color(THEME);
        buffer.vertex(matrix, 0.0F, 0.0F, 0.0F).texture(0.0F, 0.0F).color(THEME);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        matrices.pop();
    }

    // ---------------------------------------------------------------- Fire

    private static int applyOpacity(int argb, float opacity) {
        opacity = Math.min(1.0F, Math.max(0.0F, opacity));
        int a = (int) (((argb >>> 24) & 255) * opacity);
        return (a << 24) | (argb & 0xFFFFFF);
    }

    private static void fire(Entity target) {
        MinecraftClient mc = mc();
        Camera camera = mc.gameRenderer.getCamera();
        Vec3d targetPos = target.getLerpedPos(tickDelta()).subtract(camera.getPos());
        double tPosX = targetPos.x;
        double tPosY = targetPos.y;
        double tPosZ = targetPos.z;
        float iAge = (float) target.age + tickDelta();
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
        RenderSystem.setShaderTexture(0, FIRE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

        boolean visible = mc.player.canSee(target);
        if (visible) {
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
        } else {
            RenderSystem.disableDepthTest();
        }

        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        float ageMultiplier = iAge * 2.5F;

        for (int j = 0; j < 3; ++j) {
            float jOffset = (float) (j * 120);
            float jMultiplier = (float) (j + 1);

            for (int i = 0; i <= 14; ++i) {
                float iFloat = (float) i;
                double radians = Math.toRadians((((iFloat / 1.5F + iAge) * 8.0F + jOffset) % 2880.0F));
                double sinQuad = Math.sin(Math.toRadians(ageMultiplier + (float) i * jMultiplier) * 3.0) / 1.8;
                float offset = iFloat / 14.0F;
                float scale = 0.3F;
                int color = applyOpacity(THEME, offset);
                double ghostX = tPosX + Math.cos(radians) * target.getWidth();
                double ghostY = tPosY + 1.0 + sinQuad;
                double ghostZ = tPosZ + Math.sin(radians) * target.getWidth();
                MatrixStack matrices = new MatrixStack();
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
                matrices.translate(ghostX, ghostY, ghostZ);
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                Matrix4f matrix = matrices.peek().getPositionMatrix();
                buffer.vertex(matrix, -scale, scale, 0.0F).texture(0.0F, 1.0F).color(color);
                buffer.vertex(matrix, scale, scale, 0.0F).texture(1.0F, 1.0F).color(color);
                buffer.vertex(matrix, scale, -scale, 0.0F).texture(1.0F, 0.0F).color(color);
                buffer.vertex(matrix, -scale, -scale, 0.0F).texture(0.0F, 0.0F).color(color);
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());
        if (visible) RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    // ---------------------------------------------------------------- Circle

    private static void circle(Entity target, MatrixStack matrices) {
        MinecraftClient mc = mc();
        if (target == null || target == mc.player || target instanceof ArmorStandEntity) return;

        Camera camera = mc.gameRenderer.getCamera();
        Vec3d targetPos = target.getLerpedPos(tickDelta()).subtract(camera.getPos());
        float height = target.getHeight() + 0.1F;
        double duration = 2500.0;
        double elapsed = (double) System.currentTimeMillis() % duration;
        boolean side = elapsed > duration / 2.0;
        double progress = elapsed / (duration / 2.0);
        if (side) {
            --progress;
        } else {
            progress = 1.0 - progress;
        }

        progress = progress < 0.5 ? 2.0 * progress * progress : 1.0 - Math.pow(-2.0 * progress + 2.0, 2.0) / 2.0;
        double eased = (double) (height / 1.5F) * (progress > 0.5 ? 1.0 - progress : progress) * (double) (side ? -1 : 1);
        matrices.push();
        matrices.translate(targetPos.x, targetPos.y, targetPos.z);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(SrcFactor.SRC_ALPHA, DstFactor.ONE);
        RenderSystem.disableCull();

        boolean visible = mc.player.canSee(target);
        if (visible) {
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
        } else {
            RenderSystem.disableDepthTest();
        }

        GL11.glEnable(2848);
        GL11.glHint(3154, 4354);
        int bloomColor = THEME;
        int coreColor = (THEME & 0xFFFFFF) | (1 << 24);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder buffer = Tessellator.getInstance().begin(DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        for (int i = 0; i <= 360; ++i) {
            double angle = Math.toRadians(i);
            float x = (float) (Math.cos(angle) * target.getWidth());
            float z = (float) (Math.sin(angle) * target.getWidth());
            buffer.vertex(matrix, x, (float) (height * progress + eased), z).color(coreColor);
            buffer.vertex(matrix, x, (float) (height * progress), z).color(bloomColor);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());

        buffer = Tessellator.getInstance().begin(DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= 360; ++i) {
            double angle = Math.toRadians(i);
            float x = (float) (Math.cos(angle) * target.getWidth());
            float z = (float) (Math.sin(angle) * target.getWidth());
            buffer.vertex(matrix, x, (float) (height * progress), z).color(bloomColor);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());

        GL11.glDisable(2848);
        RenderSystem.enableCull();
        if (visible) RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        matrices.pop();
    }
}
