package nursultantest;

import java.util.List;

/** A group of on/off checkboxes (like "Targets" or "Options"). */
public class MultiSetting extends Setting {
    public final List<BoolSetting> items;
    public boolean expanded;

    public MultiSetting(String name, BoolSetting... items) {
        super(name);
        this.items = List.of(items);
    }

    public boolean get(String itemName) {
        for (BoolSetting b : items) {
            if (b.name.equals(itemName)) return b.value;
        }
        return false;
    }

    public int enabledCount() {
        int n = 0;
        for (BoolSetting b : items) if (b.value) n++;
        return n;
    }
}
