package nursultantest;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;

public class MainMenuScreen extends Screen {
    private static final String[] LABELS = {"Одиночная игра", "Сетевая игра", "Аккаунты", "Настройки", "Выйти"};
    private static final int BH = 24;
    private static final int GAP = 6;

    public MainMenuScreen() {
        super(Text.literal(NursultanClient.CLIENT_NAME));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private int bw() {
        return Math.max(120, Math.min(170, width / 5));
    }

    private int bx() {
        return (int) (width * 0.77) - bw() / 2;
    }

    private int by(int i) {
        int start = (int) (height * 0.17) + 62;
        int y = start + i * (BH + GAP);
        return i == 4 ? y + 14 : y;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Ui.background(ctx, width, height);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        Ui.logo(ctx, textRenderer, (int) (width * 0.27), (int) (height * 0.48), height * 0.55f / 9f);

        String[] words = NursultanClient.CLIENT_NAME.split(" ", 2);
        float cx = width * 0.77f;
        float ty = height * 0.17f;
        Ui.gradientText(ctx, textRenderer, words[0], cx, ty, 2.4f, 0xFFB070FF, 0xFFE8D4FF);
        if (words.length > 1) {
            Ui.gradientText(ctx, textRenderer, words[1], cx, ty + 24, 2.4f, 0xFFB070FF, 0xFFE8D4FF);
        }

        for (int i = 0; i < LABELS.length; i++) {
            boolean hover = Ui.hit(mouseX, mouseY, bx(), by(i), bw(), BH);
            Ui.button(ctx, textRenderer, LABELS[i], bx(), by(i), bw(), BH, hover, false);
        }

        ctx.drawText(textRenderer, "Аккаунт: " + AccountManager.current(), 6, height - 12, Ui.LAVENDER, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (int i = 0; i < LABELS.length; i++) {
                if (!Ui.hit(mouseX, mouseY, bx(), by(i), bw(), BH)) continue;
                switch (i) {
                    case 0 -> client.setScreen(new SelectWorldScreen(this));
                    case 1 -> client.setScreen(new MultiplayerScreen(this));
                    case 2 -> client.setScreen(new AccountsScreen(this));
                    case 3 -> client.setScreen(new OptionsScreen(this, client.options));
                    default -> client.scheduleStop();
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
