package nursultantest;

import java.util.function.BooleanSupplier;

public abstract class Setting {
    public final String name;
    private BooleanSupplier visible = () -> true;

    protected Setting(String name) {
        this.name = name;
    }

    /** Show this setting only while the condition is true. */
    @SuppressWarnings("unchecked")
    public <T extends Setting> T showIf(BooleanSupplier condition) {
        this.visible = condition;
        return (T) this;
    }

    public boolean isVisible() {
        return visible.getAsBoolean();
    }
}
