package nursultantest;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Ported from Xyeta AntiBot. The original reacted to tab-list packets; here the tab list is
 * scanned every tick instead (same checks, no packet mixin needed).
 */
public class AntiBot extends Module {
    private final Set<UUID> suspectSet = new HashSet<>();
    private final Set<UUID> seen = new HashSet<>();
    private static final Set<UUID> BOT_SET = new HashSet<>();

    public final ModeSetting mode = add(new ModeSetting("Mode", "Matrix", "Matrix", "ReallyWorld"));
    public final BoolSetting removeBot = add(new BoolSetting("RemoveBot", false));

    public AntiBot() {
        super("Anti Bot", Category.COMBAT);
    }

    @Override
    public void onDisable() {
        suspectSet.clear();
        seen.clear();
        BOT_SET.clear();
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null || mc.getNetworkHandler() == null) return;

        scanTabList(mc);

        if (!suspectSet.isEmpty()) {
            List<PlayerEntity> suspects = new ArrayList<>();
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (suspectSet.contains(p.getUuid())) suspects.add(p);
            }
            suspects.forEach(this::evaluateSuspectPlayer);
        }

        if (mode.is("Matrix")) matrixMode(mc);
        else reallyWorldMode(mc);

        if (removeBot.value) {
            List<Integer> toRemove = new ArrayList<>();
            for (PlayerEntity p : mc.world.getPlayers()) {
                if (p != null && p.getUuid() != null && BOT_SET.contains(p.getUuid())) toRemove.add(p.getId());
            }
            toRemove.forEach(id -> mc.world.removeEntity(id, Entity.RemovalReason.DISCARDED));
        }
    }

    private void scanTabList(MinecraftClient mc) {
        ClientPlayNetworkHandler handler = mc.getNetworkHandler();
        Set<UUID> present = new HashSet<>();
        for (PlayerListEntry entry : handler.getPlayerList()) {
            GameProfile profile = entry.getProfile();
            if (profile == null) continue;
            present.add(profile.getId());
            if (seen.add(profile.getId()) && !isRealPlayer(entry, profile)) {
                if (isDuplicateProfile(profile)) BOT_SET.add(profile.getId());
                else suspectSet.add(profile.getId());
            }
        }
        // players that left the server
        seen.removeIf(id -> !present.contains(id));
        suspectSet.removeIf(id -> !present.contains(id));
        BOT_SET.removeIf(id -> !present.contains(id) && mc.world.getPlayerByUuid(id) == null);
    }

    private boolean isRealPlayer(PlayerListEntry entry, GameProfile profile) {
        return entry.getLatency() < 2 || (profile.getProperties() != null && !profile.getProperties().isEmpty());
    }

    private void evaluateSuspectPlayer(PlayerEntity player) {
        List<ItemStack> armor = null;
        if (!isFullyEquipped(player)) armor = armorOf(player);
        if (isFullyEquipped(player) || hasArmorChanged(player, armor)) {
            BOT_SET.add(player.getUuid());
        }
        suspectSet.remove(player.getUuid());
    }

    private void matrixMode(MinecraftClient mc) {
        for (Iterator<UUID> it = suspectSet.iterator(); it.hasNext(); it.remove()) {
            UUID sus = it.next();
            PlayerEntity entity = mc.world.getPlayerByUuid(sus);
            if (entity == null) continue;
            String playerName = entity.getName().getString();
            boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.contains("[ZNPC]");
            int armorCount = 0;
            for (ItemStack item : entity.getArmorItems()) {
                if (!item.isEmpty()) armorCount++;
            }
            boolean isFullArmor = armorCount == 4;
            boolean isFakeUuid = !entity.getUuid().equals(offlineUuid(playerName));
            if (isFullArmor || isNameBot || isFakeUuid) BOT_SET.add(sus);
        }
        if (mc.player.age % 100 == 0) {
            BOT_SET.removeIf(uuid -> mc.world.getPlayerByUuid(uuid) == null);
        }
    }

    private void reallyWorldMode(MinecraftClient mc) {
        for (PlayerEntity entity : mc.world.getPlayers()) {
            String name = entity.getName().getString();
            if (!entity.getUuid().equals(offlineUuid(name)) && !BOT_SET.contains(entity.getUuid())
                    && !name.contains("NPC") && !name.startsWith("[ZNPC]")) {
                BOT_SET.add(entity.getUuid());
            }
        }
    }

    private boolean isDuplicateProfile(GameProfile profile) {
        return MinecraftClient.getInstance().getNetworkHandler().getPlayerList().stream()
                .filter(p -> p.getProfile().getName().equals(profile.getName()) && !p.getProfile().getId().equals(profile.getId()))
                .count() == 1L;
    }

    private static List<ItemStack> armorOf(PlayerEntity entity) {
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack s : entity.getArmorItems()) list.add(s);
        return list;
    }

    private boolean isFullyEquipped(PlayerEntity entity) {
        List<ItemStack> armor = armorOf(entity);
        if (armor.size() < 4) return false;
        for (int i = 0; i < 4; i++) {
            ItemStack stack = armor.get(i);
            if (stack == null || stack.isEmpty()) return false;
            if (!(stack.getItem() instanceof ArmorItem)) return false;
            if (stack.hasEnchantments()) return false;
        }
        return true;
    }

    private boolean hasArmorChanged(PlayerEntity entity, List<ItemStack> prev) {
        if (prev == null) return true;
        List<ItemStack> current = armorOf(entity);
        if (current.size() != prev.size()) return true;
        for (int i = 0; i < current.size(); i++) {
            if (!current.get(i).equals(prev.get(i))) return true;
        }
        return false;
    }

    private static UUID offlineUuid(String name) {
        return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
    }

    // ---------- queried by Kill Aura ----------

    public boolean isBot(LivingEntity entity) {
        String playerName = entity.getName().getString();
        boolean isNameBot = playerName.startsWith("CIT-") && !playerName.contains("NPC") && !playerName.startsWith("[ZNPC]");
        return isNameBot || BOT_SET.contains(entity.getUuid()) || isBotU(entity);
    }

    private boolean isBotU(Entity entity) {
        String name = entity.getName().getString();
        return !entity.getUuid().equals(offlineUuid(name)) && entity.isInvisible()
                && !name.contains("NPC") && !name.startsWith("[ZNPC]");
    }
}
