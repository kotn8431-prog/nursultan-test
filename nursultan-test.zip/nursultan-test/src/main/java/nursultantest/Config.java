package nursultantest;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves keybinds and module settings to .minecraft/config/nursultantest.properties */
public final class Config {
    private Config() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nursultantest.properties");
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) return;
        Properties props = new Properties();
        try (Reader r = Files.newBufferedReader(path)) {
            props.load(r);
        } catch (IOException e) {
            return;
        }
        for (Module m : ModuleManager.ALL) {
            m.key = parseInt(props.getProperty("bind." + m.name), m.key);
            for (Setting s : m.settings) {
                if (s instanceof MultiSetting multi) {
                    for (BoolSetting b : multi.items) read(props, "set." + m.name + "." + s.name + "." + b.name, b);
                } else {
                    read(props, "set." + m.name + "." + s.name, s);
                }
            }
        }
    }

    private static void read(Properties props, String key, Setting s) {
        String v = props.getProperty(key);
        if (v == null) return;
        if (s instanceof BoolSetting b) {
            b.value = Boolean.parseBoolean(v);
        } else if (s instanceof NumberSetting n) {
            try {
                n.value = Math.max(n.min, Math.min(n.max, Double.parseDouble(v)));
            } catch (NumberFormatException ignored) {
            }
        } else if (s instanceof ModeSetting mode) {
            mode.set(v);
        }
    }

    public static void save() {
        Properties props = new Properties();
        for (Module m : ModuleManager.ALL) {
            props.setProperty("bind." + m.name, Integer.toString(m.key));
            for (Setting s : m.settings) {
                if (s instanceof MultiSetting multi) {
                    for (BoolSetting b : multi.items) write(props, "set." + m.name + "." + s.name + "." + b.name, b);
                } else {
                    write(props, "set." + m.name + "." + s.name, s);
                }
            }
        }
        try (Writer w = Files.newBufferedWriter(file())) {
            props.store(w, "Nursultan Test config");
        } catch (IOException ignored) {
        }
    }

    private static void write(Properties props, String key, Setting s) {
        String v = null;
        if (s instanceof BoolSetting b) v = Boolean.toString(b.value);
        else if (s instanceof NumberSetting n) v = Double.toString(n.value);
        else if (s instanceof ModeSetting mode) v = mode.get();
        if (v != null) props.setProperty(key, v);
    }

    private static int parseInt(String s, int def) {
        if (s == null) return def;
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
