package nursultantest;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Saves keybinds and module settings to .minecraft/config/nursultantest.properties */
public final class Config {
    private Config() {
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("nursultantest.properties");
    }

    public static void load() {
        Path path = file();
        if (!Files.exists(path)) return;
        Properties props = new Properties();
        try (Reader r = Files.newBufferedReader(path)) {
            props.load(r);
        } catch (IOException e) {
            return;
        }
        for (Module m : ModuleManager.ALL) {
            m.key = parseInt(props.getProperty("bind." + m.name), m.key);
            for (Setting s : m.settings) {
                String v = props.getProperty("set." + m.name + "." + s.name);
                if (v == null) continue;
                if (s instanceof BoolSetting b) b.value = Boolean.parseBoolean(v);
                else if (s instanceof NumberSetting n) {
                    try {
                        n.value = Math.max(n.min, Math.min(n.max, Double.parseDouble(v)));
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }
    }

    public static void save() {
        Properties props = new Properties();
        for (Module m : ModuleManager.ALL) {
            props.setProperty("bind." + m.name, Integer.toString(m.key));
            for (Setting s : m.settings) {
                String v = s instanceof BoolSetting b ? Boolean.toString(b.value)
                        : s instanceof NumberSetting n ? Double.toString(n.value) : null;
                if (v != null) props.setProperty("set." + m.name + "." + s.name, v);
            }
        }
        try (Writer w = Files.newBufferedWriter(file())) {
            props.store(w, "Nursultan Test config");
        } catch (IOException ignored) {
        }
    }

    private static int parseInt(String s, int def) {
        if (s == null) return def;
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
