package nursultantest;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class AccountsScreen extends Screen {
    private static final int PW = 232;
    private static final int ROW = 18;
    private static final int MAX_ROWS = 6;

    private final Screen parent;
    private TextFieldWidget field;
    private String status = "";
    private int statusColor = Ui.LAVENDER;

    public AccountsScreen(Screen parent) {
        super(Text.literal("Аккаунты"));
        this.parent = parent;
    }

    private int px() {
        return (width - PW) / 2;
    }

    private int py() {
        return Math.max(8, height / 2 - 125);
    }

    private int fieldY() {
        return py() + 56;
    }

    private int btnY() {
        return py() + 84;
    }

    private int listY() {
        return py() + 120;
    }

    @Override
    protected void init() {
        field = new TextFieldWidget(textRenderer, px() + 16, fieldY(), PW - 32, 20, Text.literal("Ник"));
        field.setMaxLength(16);
        field.setPlaceholder(Text.literal("Введите свой ник"));
        field.setText(AccountManager.current());
        addDrawableChild(field);
        setInitialFocus(field);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        Ui.background(ctx, width, height);
        int rows = Math.min(MAX_ROWS, AccountManager.saved().size());
        int ph = 120 - 8 + 18 + rows * ROW + 14;
        RenderUtil.roundedBorder(ctx, px(), py() - 8, PW, ph + 8, 8, 0x66B070FF, 0xE6120824);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        int px = px();
        Ui.gradientText(ctx, textRenderer, "Аккаунты", width / 2f, py() + 4, 1.6f, 0xFFB070FF, 0xFFE8D4FF);
        String cur = "Текущий ник: " + AccountManager.current();
        ctx.drawText(textRenderer, cur, px + (PW - textRenderer.getWidth(cur)) / 2, py() + 30, Ui.LAVENDER, false);
        if (!status.isEmpty()) {
            ctx.drawText(textRenderer, status, px + (PW - textRenderer.getWidth(status)) / 2, py() + 42, statusColor, false);
        }

        int bw = (PW - 32 - 4) / 2;
        Ui.button(ctx, textRenderer, "Случайный ник", px + 16, btnY(), bw, 22,
                Ui.hit(mouseX, mouseY, px + 16, btnY(), bw, 22), false);
        Ui.button(ctx, textRenderer, "Войти", px + 16 + bw + 4, btnY(), bw, 22,
                Ui.hit(mouseX, mouseY, px + 16 + bw + 4, btnY(), bw, 22), true);

        List<String> saved = new ArrayList<>(AccountManager.saved());
        if (!saved.isEmpty()) {
            ctx.drawText(textRenderer, "Сохранённые:", px + 16, listY() - 11, 0xFF9A86C4, false);
        }
        for (int i = 0; i < Math.min(MAX_ROWS, saved.size()); i++) {
            int ry = listY() + i * ROW;
            String nick = saved.get(i);
            boolean hover = Ui.hit(mouseX, mouseY, px + 16, ry, PW - 32, ROW - 2);
            boolean cur2 = nick.equals(AccountManager.current());
            Ui.button(ctx, textRenderer, "", px + 16, ry, PW - 32, ROW - 2, hover, cur2);
            ctx.drawText(textRenderer, nick, px + 24, ry + 5, Ui.WHITE, false);
            ctx.drawText(textRenderer, "x", px + PW - 16 - 12, ry + 5, hover ? 0xFFFF7A9A : 0xFF9A86C4, false);
        }

        String back = "Назад (Esc)";
        int by = Math.min(height - 28, listY() + Math.min(MAX_ROWS, saved.size()) * ROW + 6);
        Ui.button(ctx, textRenderer, back, px + 16, by, PW - 32, 20,
                Ui.hit(mouseX, mouseY, px + 16, by, PW - 32, 20), false);
    }

    private void apply(String nick) {
        nick = nick.trim();
        if (!AccountManager.isValid(nick)) {
            status = "Ник: 3-16 символов, A-Z, 0-9 и _";
            statusColor = 0xFFFF7A9A;
            return;
        }
        try {
            AccountManager.login(nick);
            field.setText(nick);
            status = "Вы играете как " + nick;
            statusColor = 0xFF8CFFB0;
        } catch (ReflectiveOperationException | RuntimeException e) {
            status = "Не удалось сменить ник";
            statusColor = 0xFFFF7A9A;
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            int px = px();
            int bw = (PW - 32 - 4) / 2;
            if (Ui.hit(mx, my, px + 16, btnY(), bw, 22)) {
                String nick = AccountManager.randomNick();
                field.setText(nick);
                apply(nick);
                return true;
            }
            if (Ui.hit(mx, my, px + 16 + bw + 4, btnY(), bw, 22)) {
                apply(field.getText());
                return true;
            }
            List<String> saved = new ArrayList<>(AccountManager.saved());
            for (int i = 0; i < Math.min(MAX_ROWS, saved.size()); i++) {
                int ry = listY() + i * ROW;
                if (!Ui.hit(mx, my, px + 16, ry, PW - 32, ROW - 2)) continue;
                if (mx >= px + PW - 16 - 18) {
                    AccountManager.forget(saved.get(i));
                } else {
                    apply(saved.get(i));
                }
                return true;
            }
            int by = Math.min(height - 28, listY() + Math.min(MAX_ROWS, saved.size()) * ROW + 6);
            if (Ui.hit(mx, my, px + 16, by, PW - 32, 20)) {
                close();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if ((keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) && field.isFocused()) {
            apply(field.getText());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
