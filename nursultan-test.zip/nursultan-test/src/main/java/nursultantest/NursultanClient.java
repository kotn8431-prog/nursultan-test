package nursultantest;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class NursultanClient implements ClientModInitializer {
    public static final String CLIENT_NAME = "Pasted Client";

    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        Config.load();
        AccountManager.load();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nursultantest.gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.nursultantest"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // replace the vanilla title screen with our menu
            if (client.currentScreen != null && client.currentScreen.getClass() == TitleScreen.class) {
                client.setScreen(new MainMenuScreen());
            }

            while (openGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }

            pollModuleBinds(client);
            tickAutoSprint(client);
            ModuleManager.tick(client);
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> HudRenderer.render(ctx));
    }

    /** Toggles modules by their bound key (only while no screen is open). */
    private void pollModuleBinds(MinecraftClient client) {
        long window = client.getWindow().getHandle();
        for (Module m : ModuleManager.ALL) {
            if (m.key < 0) {
                m.keyDown = false;
                continue;
            }
            boolean down = InputUtil.isKeyPressed(window, m.key);
            if (down && !m.keyDown && client.currentScreen == null && client.player != null) {
                m.toggle();
            }
            m.keyDown = down;
        }
    }

    private void tickAutoSprint(MinecraftClient client) {
        if (!ModuleManager.AUTO_SPRINT.enabled) return;
        ClientPlayerEntity player = client.player;
        if (player == null) return;

        if (client.options.forwardKey.isPressed()
                && !player.isSneaking()
                && !player.isUsingItem()
                && !player.horizontalCollision
                && player.getHungerManager().getFoodLevel() > 6) {
            player.setSprinting(true);
        }
    }
}
