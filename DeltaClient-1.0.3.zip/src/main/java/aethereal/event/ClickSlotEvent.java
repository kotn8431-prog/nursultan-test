package aethereal.event;

import aethereal.core.Event;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Вызывается в начале ClientPlayerInteractionManager#clickSlot.
 * Отмена события отменяет клик целиком (в том числе предсказание на клиенте).
 */
public class ClickSlotEvent extends Event {
    private final int syncId;
    private final int slotId;
    private final int button;
    private final SlotActionType actionType;

    public ClickSlotEvent(int syncId, int slotId, int button, SlotActionType actionType) {
        this.syncId = syncId;
        this.slotId = slotId;
        this.button = button;
        this.actionType = actionType;
    }

    public int getSyncId() {
        return this.syncId;
    }

    public int getSlotId() {
        return this.slotId;
    }

    public int getButton() {
        return this.button;
    }

    public SlotActionType getActionType() {
        return this.actionType;
    }
}
