package aethereal.module.movement;

import aethereal.core.*;
import aethereal.core.Module;
import aethereal.event.PacketEvent;
import aethereal.event.RemovalsEvent;
import aethereal.event.TickEvent;
import aethereal.notification.Notification;
import aethereal.render.ColorUtil;
import aethereal.setting.BooleanSetting;
import aethereal.setting.MultiModeSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.SpectralArrowEntity;
import net.minecraft.entity.projectile.thrown.EggEntity;
import net.minecraft.entity.projectile.thrown.ExperienceBottleEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;

import java.util.ArrayList;
import java.util.List;

@ModuleRegister(name = "NoRender", description = "Убирает лишние сущности, оверлеи и титры, снижая нагрузку и визуальный мусор", category = Category.Movement)
public class NoRender extends Module {
    // Лимиты для авто-режима (как в ThunderHack)
    private static final int ARROW_LIMIT = 64;
    private static final int ITEM_LIMIT = 16;
    private static final int XP_LIMIT = 16;
    private static final int POTION_LIMIT = 8;

    // --- Сущности ---
    private final BooleanSetting potions = new BooleanSetting("Зелья", false);
    private final BooleanSetting xp = new BooleanSetting("Пузырьки опыта", false);
    private final BooleanSetting arrows = new BooleanSetting("Стрелы", false);
    private final BooleanSetting eggs = new BooleanSetting("Яйца", false);
    private final BooleanSetting items = new BooleanSetting("Предметы", false);
    private final BooleanSetting crystals = new BooleanSetting("Кристаллы", false);
    private final BooleanSetting armorStands = new BooleanSetting("Стойки для брони", false);
    private final MultiModeSetting entities = new MultiModeSetting("Удалять сущности", potions, xp, arrows, eggs, items, crystals, armorStands);

    // --- Оверлеи и HUD (используют уже существующие хуки RemovalsEvent) ---
    private final BooleanSetting hurtCam = new BooleanSetting("Тряска при уроне", true);
    private final BooleanSetting portal = new BooleanSetting("Эффект портала", true);
    private final BooleanSetting fire = new BooleanSetting("Огонь на экране", false);
    private final BooleanSetting water = new BooleanSetting("Вода/лава на экране", false);
    private final BooleanSetting nausea = new BooleanSetting("Тошнота", false);
    private final BooleanSetting blindness = new BooleanSetting("Слепота", false);
    private final BooleanSetting darkness = new BooleanSetting("Тьма", false);
    private final BooleanSetting breakParticles = new BooleanSetting("Частицы разрушения", true);
    private final BooleanSetting weather = new BooleanSetting("Погода", false);
    private final BooleanSetting scoreboard = new BooleanSetting("Скорборд", true);
    private final BooleanSetting bossbar = new BooleanSetting("Боссбар", false);
    private final MultiModeSetting overlays = new MultiModeSetting("Эффекты и HUD", hurtCam, portal, fire, water, nausea, blindness, darkness, breakParticles, weather, scoreboard, bossbar);

    private final BooleanSetting antiTitle = new BooleanSetting("Скрывать титры", false);
    private final BooleanSetting auto = new BooleanSetting("Авто-лимит", false);

    private long lastNotify;

    public NoRender() {
        a(this.entities, this.overlays, this.antiTitle, this.auto);
    }

    @EventTarget
    public void a(PacketEvent event) {
        if (event.isReceive() && this.antiTitle.c()
                && (event.getPacket() instanceof TitleS2CPacket || event.getPacket() instanceof SubtitleS2CPacket)) {
            event.a(true);
        }
    }

    /** Приоритет 4: срабатывает после Removals, чтобы он не сбросил наше «true». */
    @EventTarget(a = 4)
    public void a(RemovalsEvent event) {
        BooleanSetting setting = switch (event.b()) {
            case HURT_CAM -> this.hurtCam;
            case PORTAL -> this.portal;
            case FIRE -> this.fire;
            case WATER -> this.water;
            case NAUSEA -> this.nausea;
            case BLINDNESS -> this.blindness;
            case DARKNESS -> this.darkness;
            case BREAK_PARTICLES -> this.breakParticles;
            case WEATHER -> this.weather;
            case SCOREBOARD -> this.scoreboard;
            case BOSS_BAR -> this.bossbar;
            default -> null;
        };
        if (setting != null && setting.c()) {
            event.a(true);
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        if (mc.world == null || mc.player == null) {
            return;
        }

        int potionCount = 0;
        int xpCount = 0;
        int arrowCount = 0;
        int itemCount = 0;
        List<Entity> found = new ArrayList<>();
        for (Entity entity : mc.world.getEntities()) {
            found.add(entity);
        }

        for (Entity entity : found) {
            if (entity instanceof PotionEntity) potionCount++;
            else if (entity instanceof ExperienceBottleEntity) xpCount++;
            else if (entity instanceof ArrowEntity || entity instanceof SpectralArrowEntity) arrowCount++;
            else if (entity instanceof ItemEntity) itemCount++;
        }

        boolean overPotions = this.auto.c() && potionCount > POTION_LIMIT;
        boolean overXp = this.auto.c() && xpCount > XP_LIMIT;
        boolean overArrows = this.auto.c() && arrowCount > ARROW_LIMIT;
        boolean overItems = this.auto.c() && itemCount > ITEM_LIMIT;

        if (overPotions) notify("Превышен лимит зелий! Удаляю...");
        if (overXp) notify("Превышен лимит пузырьков опыта! Удаляю...");
        if (overArrows) notify("Превышен лимит стрел! Удаляю...");
        if (overItems) notify("Превышен лимит предметов! Удаляю...");

        List<Integer> toRemove = new ArrayList<>();
        for (Entity entity : found) {
            boolean remove = false;
            if (entity instanceof PotionEntity) remove = this.potions.c() || overPotions;
            else if (entity instanceof ExperienceBottleEntity) remove = this.xp.c() || overXp;
            else if (entity instanceof ArrowEntity || entity instanceof SpectralArrowEntity) remove = this.arrows.c() || overArrows;
            else if (entity instanceof ItemEntity) remove = this.items.c() || overItems;
            else if (entity instanceof EggEntity) remove = this.eggs.c();
            else if (entity instanceof EndCrystalEntity) remove = this.crystals.c();
            else if (entity instanceof ArmorStandEntity) remove = this.armorStands.c();
            if (remove) {
                toRemove.add(entity.getId());
            }
        }

        for (int id : toRemove) {
            mc.world.removeEntity(id, Entity.RemovalReason.KILLED);
        }
    }

    private void notify(String text) {
        long now = System.currentTimeMillis();
        if (now - this.lastNotify < 3000L) {
            return;
        }
        this.lastNotify = now;
        Delta.getInstance().getModuleProcessor().m().a(new Notification("Q", ColorUtil.convertToARGB(100, 220, 120, 255), "NoRender: " + text, 3000));
    }
}
