package aethereal.module.movement;

import aethereal.core.*;
import aethereal.core.Module;
import aethereal.event.ClickSlotEvent;
import aethereal.event.PacketEvent;
import aethereal.event.TickEvent;
import aethereal.setting.BooleanSetting;
import aethereal.setting.ModeSetting;
import aethereal.util.MoveUtil;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.BookEditScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.SignEditScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import platform.inject.accessors.ClientConnectionAccessor;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

@ModuleRegister(name = "GuiMove", description = "Позволяет двигаться и крутить камеру стрелками с открытым инвентарём", category = Category.Movement)
public class GuiMove extends Module {
    private final ModeSetting bypass = new ModeSetting("Обход кликов", "None", "None", "DisableClicks", "StrictNCP", "StrictNCP2", "GrimSwap", "MatrixNcp", "Delay");
    private final BooleanSetting rotateOnArrows = new BooleanSetting("Поворот стрелками", true);
    private final BooleanSetting sneak = new BooleanSetting("Приседание", false);

    private final Queue<ClickSlotC2SPacket> storedClicks = new LinkedList<>();
    // Пакеты, которые отправили мы сами: их повторно обрабатывать не нужно (защита от рекурсии)
    private final Set<Packet<?>> passed = Collections.newSetFromMap(new IdentityHashMap<>());

    public GuiMove() {
        a(this.bypass, this.rotateOnArrows, this.sneak);
    }

    @Override
    public void c() {
        super.c();
        if (mc.player != null && mc.getNetworkHandler() != null) {
            flushStoredClicks();
        } else {
            this.storedClicks.clear();
        }
        this.passed.clear();
        if (mc.currentScreen != null) {
            KeyBinding.unpressAll();
        }
    }

    @EventTarget
    public void a(TickEvent event) {
        this.passed.clear();
        Screen screen = mc.currentScreen;
        if (mc.player == null || screen == null || !canMoveIn(screen)) {
            return;
        }

        for (KeyBinding key : new KeyBinding[]{mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey, mc.options.jumpKey, mc.options.sprintKey}) {
            key.setPressed(isDown(key));
        }

        if (this.sneak.c()) {
            mc.options.sneakKey.setPressed(isDown(mc.options.sneakKey));
        }

        if (this.rotateOnArrows.c()) {
            float deltaX = 0.0f;
            float deltaY = 0.0f;
            long window = mc.getWindow().getHandle();
            if (InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_DOWN)) deltaY += 30.0f;
            if (InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_UP)) deltaY -= 30.0f;
            if (InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_RIGHT)) deltaX += 30.0f;
            if (InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_LEFT)) deltaX -= 30.0f;
            if (deltaX != 0.0f || deltaY != 0.0f) {
                mc.player.changeLookDirection(deltaX, deltaY);
            }
        }
    }

    /** Отмена самого клика по слоту (режим DisableClicks). */
    @EventTarget
    public void a(ClickSlotEvent event) {
        if (this.bypass.l("DisableClicks") && isBusy()) {
            event.a(true);
        }
    }

    @EventTarget(a = 0)
    public void a(PacketEvent event) {
        if (!event.isSend() || mc.player == null || mc.world == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (this.passed.contains(packet)) {
            return;
        }

        // Закрытие экрана: выпускаем накопленные клики (режим Delay)
        if (packet instanceof CloseHandledScreenC2SPacket) {
            if (this.bypass.l("Delay")) {
                flushStoredClicks();
            }
            return;
        }

        if (!(packet instanceof ClickSlotC2SPacket click) || !isBusy()) {
            return;
        }

        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();

        if (this.bypass.l("GrimSwap")) {
            if (click.getActionType() != SlotActionType.PICKUP && click.getActionType() != SlotActionType.PICKUP_ALL) {
                send(new CloseHandledScreenC2SPacket(0));
            }
        } else if (this.bypass.l("StrictNCP")) {
            if (mc.player.isOnGround() && !mc.world.getBlockCollisions(mc.player, mc.player.getBoundingBox().offset(0.0, 0.0656, 0.0)).iterator().hasNext()) {
                boolean sprinting = mc.player.isSprinting();
                if (sprinting) {
                    send(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                }
                send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0656, z, false, mc.player.horizontalCollision));
                if (sprinting) {
                    // Клик должен уйти между STOP и START спринта
                    event.a(true);
                    send(click);
                    send(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                }
            }
        } else if (this.bypass.l("StrictNCP2")) {
            if (mc.player.isOnGround() && !mc.world.getBlockCollisions(mc.player, mc.player.getBoundingBox().offset(0.0, 0.000000271875, 0.0)).iterator().hasNext()) {
                if (mc.player.isSprinting()) {
                    send(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                }
                send(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.000000271875, z, false, mc.player.horizontalCollision));
            }
        } else if (this.bypass.l("MatrixNcp")) {
            send(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            mc.options.forwardKey.setPressed(false);
            mc.player.input.movementForward = 0.0f;
        } else if (this.bypass.l("Delay")) {
            this.storedClicks.add(click);
            event.a(true);
        }
    }

    /** Игрок двигается или прыгает — именно тогда античит видит клик «на ходу». */
    private boolean isBusy() {
        return mc.player != null && mc.player.input != null && (MoveUtil.a() || mc.options.jumpKey.isPressed());
    }

    private void flushStoredClicks() {
        while (!this.storedClicks.isEmpty()) {
            send(this.storedClicks.poll());
        }
    }

    private void send(Packet<?> packet) {
        if (mc.player == null || mc.player.networkHandler == null) {
            return;
        }
        this.passed.add(packet);
        ((ClientConnectionAccessor) mc.player.networkHandler.getConnection()).sendWithoutEvent(packet, null, true);
    }

    /** Экраны с вводом текста исключаем, иначе W/A/S/D будут двигать игрока при наборе. */
    private static boolean canMoveIn(Screen screen) {
        if (screen instanceof ChatScreen || screen instanceof SignEditScreen || screen instanceof AnvilScreen
                || screen instanceof CreativeInventoryScreen || screen instanceof BookEditScreen) {
            return false;
        }
        return !(screen.getFocused() instanceof TextFieldWidget);
    }

    /** Реальное состояние клавиши с учётом переназначения и мыши. */
    private static boolean isDown(KeyBinding binding) {
        InputUtil.Key key = InputUtil.fromTranslationKey(binding.getBoundKeyTranslationKey());
        if (key == InputUtil.UNKNOWN_KEY) {
            return false;
        }
        long window = mc.getWindow().getHandle();
        if (key.getCategory() == InputUtil.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(window, key.getCode()) == GLFW.GLFW_PRESS;
        }
        return InputUtil.isKeyPressed(window, key.getCode());
    }
}
