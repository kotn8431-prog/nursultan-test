package aethereal.render;

import aethereal.core.Interface;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

/**
 * Target ESP "ThunderHackV2" — перенос Render3DEngine.renderGhosts из ThunderHack-Recode.
 */
public class GhostsMark {
    private static final Identifier FIREFLY = Identifier.of("delta", "pictures/firefly.png");

    // значения по умолчанию из ThunderHack (ESPLength / ESPFactor / ESPShaking / ESPAmplitude)
    public static final int LENGTH = 14;
    public static final int FACTOR = 8;
    public static final float SHAKING = 1.8f;
    public static final float AMPLITUDE = 3f;

    public static void render(Entity target, int color, float alpha) {
        render(LENGTH, FACTOR, SHAKING, AMPLITUDE, target, color, alpha);
    }

    public static void render(int espLength, int factor, float shaking, float amplitude, Entity target, int color, float alpha) {
        float tickDelta = Interface.mc.getRenderTickCounter().getTickDelta(true);
        Camera camera = Interface.mc.gameRenderer.getCamera();

        double tPosX = MathHelper.lerp(tickDelta, target.prevX, target.getX()) - camera.getPos().x;
        double tPosY = MathHelper.lerp(tickDelta, target.prevY, target.getY()) - camera.getPos().y;
        double tPosZ = MathHelper.lerp(tickDelta, target.prevZ, target.getZ()) - camera.getPos().z;
        float iAge = MathHelper.lerp(tickDelta, target.age - 1, target.age);

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.setShaderTexture(0, FIREFLY);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        boolean canSee = Interface.mc.player.canSee(target);

        if (canSee) {
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
        } else RenderSystem.disableDepthTest();

        for (int j = 0; j < 3; j++) {
            for (int i = 0; i <= espLength; i++) {
                double radians = Math.toRadians((((float) i / 1.5f + iAge) * factor + (j * 120)) % (factor * 360));
                double sinQuad = Math.sin(Math.toRadians(iAge * 2.5f + i * (j + 1)) * amplitude) / shaking;

                float offset = ((float) i / espLength);
                MatrixStack matrices = new MatrixStack();
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(camera.getYaw() + 180.0F));
                matrices.translate(tPosX + Math.cos(radians) * target.getWidth(), (tPosY + 1 + sinQuad), tPosZ + Math.sin(radians) * target.getWidth());
                matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-camera.getYaw()));
                matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(camera.getPitch()));
                Matrix4f matrix = matrices.peek().getPositionMatrix();

                int a = (int) (255 * MathHelper.clamp(offset * alpha, 0f, 1f));
                int c = (color & 0xFFFFFF) | (a << 24);
                float scale = Math.max(0.24f * (offset), 0.2f);
                buffer.vertex(matrix, -scale, scale, 0).texture(0f, 1f).color(c);
                buffer.vertex(matrix, scale, scale, 0).texture(1f, 1f).color(c);
                buffer.vertex(matrix, scale, -scale, 0).texture(1f, 0).color(c);
                buffer.vertex(matrix, -scale, -scale, 0).texture(0, 0).color(c);
            }
        }

        BufferRenderer.drawWithGlobalProgram(buffer.end());

        if (canSee) {
            RenderSystem.depthMask(true);
            RenderSystem.disableDepthTest();
        } else RenderSystem.enableDepthTest();

        RenderSystem.disableBlend();
    }
}
