package aethereal.ui.widget;

import aethereal.config.ThemeInfo;
import aethereal.core.Delta;
import aethereal.core.GlobalEvent;
import aethereal.core.Interface;
import aethereal.event.DrawEvent;
import aethereal.module.misc.StreamerMode;
import aethereal.render.ColorUtil;
import aethereal.render.Draw2DProcessor;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.ui.element.DragInfo;
import aethereal.util.ServerUtil;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Таргет-худ 2 (Target HUD minced) — порт из sweetie.evaware.TargetInfoMincedWidget.
 */
public class TargetHud2Widget extends Widget {
    public static final String NAME = "Таргет-худ 2";

    private LivingEntity target;
    private float healthAnimation = 0f;
    private float absorptionAnimation = 0f;
    private float lastHealth = -1f;
    private float hitFlash = 0f;
    private float hitFlashTarget = 0f;

    private final List<HitParticle> particles = new ArrayList<>();
    private final Random random = new Random();

    private static class HitParticle {
        float x, y, vx, vy, life, maxLife, size;
        int color;

        HitParticle(float x, float y, float vx, float vy, float life, float size, int color) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.life = life;
            this.maxLife = life;
            this.size = size;
            this.color = color;
        }

        boolean update() {
            x += vx;
            y += vy;
            vy += 0.02f;
            vx *= 0.97f;
            vy *= 0.97f;
            life -= 1f;
            return life <= 0;
        }

        float alpha() {
            return life / maxLife;
        }
    }

    public TargetHud2Widget() {
        super(new DragInfo(NAME, 30.0f, 30.0f, 118.0f, 42.0f));
        j().setWidget(this);
    }

    private static float lerp(float from, float to, float f) {
        return from + (to - from) * f;
    }

    private static int argb(int r, int g, int b, int a) {
        return ColorUtil.convertToARGB(
                MathHelper.clamp(r, 0, 255), MathHelper.clamp(g, 0, 255),
                MathHelper.clamp(b, 0, 255), MathHelper.clamp(a, 0, 255));
    }

    private static int red(int c) {
        return (c >> 16) & 255;
    }

    private static int green(int c) {
        return (c >> 8) & 255;
    }

    private static int blue(int c) {
        return c & 255;
    }

    @Override
    public void a(DrawEvent event) {
        d().a(0.0f, 1.0f, 0.3f, EasingList.g, event.g());
        float anim = a();

        if (anim > 0.01f && this.target != null) {
            renderHud(event, anim);
        }
        super.a(event);
    }

    private void renderHud(DrawEvent event, float anim) {
        MatrixStack ms = event.h();
        Draw2DProcessor draw = event.getDraw2DProcessor();
        int fa = (int) (anim * 255f);

        // размеры
        float headSize = 34f;
        float padding = 4f;
        float gap = 4f;
        float barH = 5.5f;
        float barRound = 0.8f;
        float round = 9f;
        float width = 118f;
        float height = headSize + padding * 2f;

        j().setWidth(width);
        j().setHeight(height);

        float x = j().getClampedX();
        float y = j().getClampedY();

        float currentHp = ServerUtil.a.a$(this.target);
        float maxHp = Math.max(this.target.getMaxHealth(), 1f);
        float absorptionHp = this.target.getAbsorptionAmount();

        boolean gotHit = this.lastHealth > 0 && currentHp < this.lastHealth;
        if (gotHit) {
            this.hitFlashTarget = 1f;
        }
        this.lastHealth = currentHp;

        if (this.hitFlashTarget > 0) {
            this.hitFlash = lerp(this.hitFlash, this.hitFlashTarget, 0.25f);
            if (this.hitFlash >= 0.95f) {
                this.hitFlash = 1f;
                this.hitFlashTarget = 0f;
            }
        } else {
            this.hitFlash = lerp(this.hitFlash, 0f, 0.08f);
            if (this.hitFlash < 0.01f) {
                this.hitFlash = 0f;
            }
        }

        this.healthAnimation = MathHelper.clamp(lerp(this.healthAnimation, currentHp / maxHp, 0.1f), 0f, 1f);
        float absorptionPercent = absorptionHp > 0 ? Math.min(absorptionHp / maxHp, 1f) : 0f;
        this.absorptionAnimation = MathHelper.clamp(lerp(this.absorptionAnimation, absorptionPercent, 0.08f), 0f, 1f);

        float headX = x + padding;
        float headY = y + (height - headSize) / 2f;

        int primary = Delta.getInstance().getModuleProcessor().o().a(ThemeInfo.PRIMARY).toIntColor();
        int themeColor = ColorUtil.applyAlphaToColor(primary, anim);

        // частицы при ударе
        if (gotHit) {
            int count = 14;
            for (int i = 0; i < count; i++) {
                float angle = (float) (i * (Math.PI * 2 / count) + this.random.nextFloat() * 0.3f);
                float radius = headSize / 2f;
                float cx = headX + headSize / 2f + (float) (Math.cos(angle) * radius);
                float cy = headY + headSize / 2f + (float) (Math.sin(angle) * radius);
                float speed = 0.3f + this.random.nextFloat() * 0.5f;
                float vx = (float) (Math.cos(angle) * speed);
                float vy = (float) (Math.sin(angle) * speed);
                float size = 2f + this.random.nextFloat() * 2f;
                float life = 20f + this.random.nextFloat() * 15f;
                this.particles.add(new HitParticle(cx, cy, vx, vy, life, size, primary));
            }
        }

        Iterator<HitParticle> iter = this.particles.iterator();
        while (iter.hasNext()) {
            if (iter.next().update()) {
                iter.remove();
            }
        }

        // тень + фон
        float shadowS = 3.5f;
        draw.a(ms, x - shadowS, y - shadowS, width + shadowS * 2f, height + shadowS * 2f,
                round + shadowS, argb(0, 0, 0, (int) (55 * anim)));
        draw.a(ms, x, y, width, height, round, argb(10, 10, 10, (int) (245 * anim)));

        // голова
        if (this.target instanceof AbstractClientPlayerEntity player) {
            draw.a(ms, player.getSkinTextures().texture(), player, headX, headY, headSize, headSize, 6f, anim);
        } else {
            draw.a(ms, headX, headY, headSize, headSize, 6f, argb(30, 30, 30, (int) (200 * anim)));
            float qSize = 18f;
            float qW = Fonts.d.a("?", qSize);
            Fonts.d.a(ms, "?", headX + headSize / 2f - qW / 2f, headY + headSize / 2f - 5f, qSize,
                    argb(255, 255, 255, fa));
        }

        // красная вспышка при ударе
        if (this.hitFlash > 0) {
            draw.a(ms, headX, headY, headSize, headSize, 6f, argb(255, 80, 80, (int) (this.hitFlash * 80 * anim)));
        }

        // текст
        float textX = headX + headSize + gap;
        float nameSize = 8f;
        float hpLabelSize = 7f;
        float hpNumSize = 7.5f;

        String name;
        StreamerMode streamerMode = Delta.getInstance().getModuleProcessor().t().aE();
        if (streamerMode.m() && streamerMode.r().c().booleanValue()) {
            name = streamerMode.a(this.target.getName().getString());
        } else {
            name = this.target.getName().getString();
        }

        float nameY = y + padding + 3f;
        float maxNameW = width - (textX - x) - padding;
        int white = argb(255, 255, 255, fa);
        if (Fonts.d.a(name, nameSize) > maxNameW) {
            Fonts.d.c(ms, name, textX, nameY, nameSize, white, maxNameW);
        } else {
            Fonts.d.a(ms, name, textX, nameY, nameSize, white);
        }

        float healthY = nameY + nameSize + 4f;
        String healthLabel = "Health:";
        float labelW = Fonts.d.a(healthLabel, hpLabelSize);
        Fonts.d.a(ms, healthLabel, textX, healthY, hpLabelSize, themeColor);

        String hpNum = String.format("%.1f", currentHp).replace(".", ",");
        Fonts.d.a(ms, hpNum, textX + labelW + 0.5f, healthY - 0.3f, hpNumSize, white);

        // полоска HP
        float barX = headX + headSize + 4f;
        float barY = y + height - padding - barH - 1.5f;
        float barW = width - (headX + headSize + 4f - x) - padding - 3f;

        int barBg = argb((int) (red(primary) * 0.2f), (int) (green(primary) * 0.2f),
                (int) (blue(primary) * 0.2f), (int) (180 * anim));
        draw.a(ms, barX, barY, barW, barH, barRound, barBg);

        if (this.healthAnimation > 0) {
            float filledW = barW * this.healthAnimation;
            if (filledW > 1f) {
                int c1 = argb(red(primary) + (255 - red(primary)) / 4,
                        green(primary) + (255 - green(primary)) / 4,
                        blue(primary) + (255 - blue(primary)) / 4, fa);
                int c2 = argb((int) (red(primary) * 0.65f), (int) (green(primary) * 0.65f),
                        (int) (blue(primary) * 0.65f), fa);
                draw.a(ms, barX, barY, filledW, barH, barRound, c1, c2, c1, c2);
            }
        }

        // золотая абсорбция
        if (absorptionHp > 0 || this.absorptionAnimation > 0.01f) {
            int gr = 255, gg = 215, gb = 0;
            int g1 = argb(gr + (255 - gr) / 4, gg + (255 - gg) / 4, gb + (255 - gb) / 4, fa);
            int g2 = argb((int) (gr * 0.65f), (int) (gg * 0.65f), (int) (gb * 0.65f), fa);
            float absW = barW * this.absorptionAnimation;
            if (absW > 0.5f) {
                draw.a(ms, barX, barY, absW, barH, barRound, g1, g2, g1, g2);
            }
        }

        // отрисовка частиц
        for (HitParticle p : this.particles) {
            int pAlpha = (int) (p.alpha() * fa);
            draw.a(ms, p.x - p.size / 2f, p.y - p.size / 2f, p.size, p.size, p.size / 2f,
                    ColorUtil.combineColorWithAlpha(p.color, MathHelper.clamp(pAlpha, 0, 255)));
        }
    }

    @Override
    public void a(GlobalEvent event) {
        LivingEntity auraTarget = Delta.getInstance().getModuleProcessor().t().B().getTarget() != null
                ? Delta.getInstance().getModuleProcessor().t().B().getTarget()
                : Delta.getInstance().getModuleProcessor().t().X().getTarget();

        LivingEntity newTarget = auraTarget != null
                ? auraTarget
                : (Interface.mc.currentScreen instanceof ChatScreen ? Interface.mc.player : null);

        boolean visible = newTarget != null;
        if (newTarget != null) {
            if (this.target != newTarget) {
                // сброс состояния при смене цели, чтобы не было ложных "ударов"
                this.lastHealth = -1f;
                this.healthAnimation = newTarget.getHealth() / Math.max(newTarget.getMaxHealth(), 1f);
                this.particles.clear();
            }
            this.target = newTarget;
        }
        d().a(visible);
        if (!visible && d().a() <= 0.0f) {
            this.target = null;
        }
        super.a(event);
    }
}
